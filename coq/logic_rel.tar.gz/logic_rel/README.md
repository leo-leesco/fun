This is the Coq/Iris development accompanying the 2023-11-22 session
"Unary logical relation with mutable store in Iris" of the course MPRI
2-4 "functional programming and type system".

In this file, we give instructions to install the dependencies of the
development. If any problem is encountered while following these
instructions, please contact the teacher of the session
(jacques-henri.jourdan@cnrs.fr).

First, you need to install opam and create a switch with a recent
version of OCaml (OCaml 4.14.1 is known to work).

Second, add the following repositories to opam:

    opam repo add coq-released https://coq.inria.fr/opam/released
    opam repo add iris-dev git+https://gitlab.mpi-sws.org/iris/opam.git
    opam update

Third, in the opam switch, pin Coq to version 8.17.1:

    opam pin add -n coq 8.16.1

Finally, install Coq and Iris:

    make builddep

In this state, the files can be compiled using `make`, browsed and
edited using Proof General, VSCode or CoqIDE (CoqIDE needs to be
installed using `opam install coqide`).
