
module MenhirBasics = struct
  
  exception Error
  
  let _eRR =
    fun _s ->
      raise Error
  
  type token = 
    | WITH
    | TYPE
    | TAG of (
# 41 "parser.mly"
       (string * Lexing.position * Lexing.position)
# 17 "parser.ml"
  )
    | SEMI
    | RPAR
    | RETURN
    | RBRACKET
    | RBRACE
    | PROGRAM
    | MATCH
    | LPAR
    | LET
    | LBRACKET
    | LBRACE
    | JUMP
    | JOIN
    | IN
    | IDENTIFIER of (
# 41 "parser.mly"
       (string * Lexing.position * Lexing.position)
# 36 "parser.ml"
  )
    | FUN
    | FORALL
    | EQ
    | EOF
    | END
    | DOT
    | DATA
    | CONSTRUCTOR
    | COLON
    | BAR
    | ARROW
  
end

include MenhirBasics

# 1 "parser.mly"
  

open List
open Syntax

let distribute (xs : 'x list) (y : 'y) : ('x * 'y) list =
  map (fun x -> (x, y)) xs

let abs te_args t =
  fold_right (fun (x, ty) t -> SynTeAbs (x, ty, t)) te_args t

let tyabs ty_args t =
  fold_right (fun a t -> SynTeTyAbs (a, t)) ty_args t

let tyapp t tys =
  fold_left (fun t ty -> SynTeTyApp (t, ty)) t tys

let otyannot t = function
  | None ->
      t
  | Some ty ->
      SynTeTyAnnot (t, ty)

let forall tvars ty =
  fold_right (fun tv ty -> SynTyForall (tv, ty)) tvars ty

let make_non_recursive_definition ty_args te_args ocodomain t =
  (* if there are no arguments at all, then this is not a function *)
  (* this special case is required to avoid ambiguity between the
     primitive form [let x = t1 in t2] and the syntactic sugar
     [let f (...) = t1 in t2], in the particular case where there
     are no arguments. *)
  tyabs ty_args (
    abs te_args (
      otyannot t ocodomain
    )
  )


# 94 "parser.ml"

type ('s, 'r) _menhir_state = 
  | MenhirState000 : ('s, _menhir_box_program) _menhir_state
    (** State 000.
        Stack shape : .
        Start symbol: program. *)

  | MenhirState001 : (('s, _menhir_box_program) _menhir_cell1_TYPE, _menhir_box_program) _menhir_state
    (** State 001.
        Stack shape : TYPE.
        Start symbol: program. *)

  | MenhirState003 : ((('s, _menhir_box_program) _menhir_cell1_TYPE, _menhir_box_program) _menhir_cell1_type_constructor, _menhir_box_program) _menhir_state
    (** State 003.
        Stack shape : TYPE type_constructor.
        Start symbol: program. *)

  | MenhirState005 : (('s, _menhir_box_program) _menhir_cell1_type_variable, _menhir_box_program) _menhir_state
    (** State 005.
        Stack shape : type_variable.
        Start symbol: program. *)

  | MenhirState009 : (('s, _menhir_box_program) _menhir_cell1_DATA, _menhir_box_program) _menhir_state
    (** State 009.
        Stack shape : DATA.
        Start symbol: program. *)

  | MenhirState013 : ((('s, _menhir_box_program) _menhir_cell1_DATA, _menhir_box_program) _menhir_cell1_data_constructor, _menhir_box_program) _menhir_state
    (** State 013.
        Stack shape : DATA data_constructor.
        Start symbol: program. *)

  | MenhirState019 : ((('s, _menhir_box_program) _menhir_cell1_DATA, _menhir_box_program) _menhir_cell1_data_constructor _menhir_cell0_loption_quantifiers_, _menhir_box_program) _menhir_state
    (** State 019.
        Stack shape : DATA data_constructor loption(quantifiers).
        Start symbol: program. *)

  | MenhirState020 : (('s, _menhir_box_program) _menhir_cell1_LPAR, _menhir_box_program) _menhir_state
    (** State 020.
        Stack shape : LPAR.
        Start symbol: program. *)

  | MenhirState021 : (('s, _menhir_box_program) _menhir_cell1_IDENTIFIER, _menhir_box_program) _menhir_state
    (** State 021.
        Stack shape : IDENTIFIER.
        Start symbol: program. *)

  | MenhirState023 : (('s, _menhir_box_program) _menhir_cell1_typ0, _menhir_box_program) _menhir_state
    (** State 023.
        Stack shape : typ0.
        Start symbol: program. *)

  | MenhirState026 : (('s, _menhir_box_program) _menhir_cell1_FORALL, _menhir_box_program) _menhir_state
    (** State 026.
        Stack shape : FORALL.
        Start symbol: program. *)

  | MenhirState028 : ((('s, _menhir_box_program) _menhir_cell1_FORALL, _menhir_box_program) _menhir_cell1_list_type_variable_, _menhir_box_program) _menhir_state
    (** State 028.
        Stack shape : FORALL list(type_variable).
        Start symbol: program. *)

  | MenhirState030 : (('s, _menhir_box_program) _menhir_cell1_typ1, _menhir_box_program) _menhir_state
    (** State 030.
        Stack shape : typ1.
        Start symbol: program. *)

  | MenhirState037 : (('s, _menhir_box_program) _menhir_cell1_typ, _menhir_box_program) _menhir_state
    (** State 037.
        Stack shape : typ.
        Start symbol: program. *)

  | MenhirState043 : (((('s, _menhir_box_program) _menhir_cell1_DATA, _menhir_box_program) _menhir_cell1_data_constructor _menhir_cell0_loption_quantifiers_, _menhir_box_program) _menhir_cell1_semi_typ_ _menhir_cell0_RBRACE, _menhir_box_program) _menhir_state
    (** State 043.
        Stack shape : DATA data_constructor loption(quantifiers) semi(typ) RBRACE.
        Start symbol: program. *)

  | MenhirState044 : ((((('s, _menhir_box_program) _menhir_cell1_DATA, _menhir_box_program) _menhir_cell1_data_constructor _menhir_cell0_loption_quantifiers_, _menhir_box_program) _menhir_cell1_semi_typ_ _menhir_cell0_RBRACE, _menhir_box_program) _menhir_cell1_type_constructor, _menhir_box_program) _menhir_state
    (** State 044.
        Stack shape : DATA data_constructor loption(quantifiers) semi(typ) RBRACE type_constructor.
        Start symbol: program. *)

  | MenhirState045 : (('s, _menhir_box_program) _menhir_cell1_typ0, _menhir_box_program) _menhir_state
    (** State 045.
        Stack shape : typ0.
        Start symbol: program. *)

  | MenhirState050 : (('s, _menhir_box_program) _menhir_cell1_signature_item, _menhir_box_program) _menhir_state
    (** State 050.
        Stack shape : signature_item.
        Start symbol: program. *)

  | MenhirState055 : (('s, _menhir_box_program) _menhir_cell1_list_signature_item_, _menhir_box_program) _menhir_state
    (** State 055.
        Stack shape : list(signature_item).
        Start symbol: program. *)

  | MenhirState056 : (('s, _menhir_box_program) _menhir_cell1_MATCH, _menhir_box_program) _menhir_state
    (** State 056.
        Stack shape : MATCH.
        Start symbol: program. *)

  | MenhirState057 : (('s, _menhir_box_program) _menhir_cell1_LPAR, _menhir_box_program) _menhir_state
    (** State 057.
        Stack shape : LPAR.
        Start symbol: program. *)

  | MenhirState058 : (('s, _menhir_box_program) _menhir_cell1_LET, _menhir_box_program) _menhir_state
    (** State 058.
        Stack shape : LET.
        Start symbol: program. *)

  | MenhirState060 : ((('s, _menhir_box_program) _menhir_cell1_LET, _menhir_box_program) _menhir_cell1_term_variable, _menhir_box_program) _menhir_state
    (** State 060.
        Stack shape : LET term_variable.
        Start symbol: program. *)

  | MenhirState061 : (('s, _menhir_box_program) _menhir_cell1_LBRACKET, _menhir_box_program) _menhir_state
    (** State 061.
        Stack shape : LBRACKET.
        Start symbol: program. *)

  | MenhirState065 : (((('s, _menhir_box_program) _menhir_cell1_LET, _menhir_box_program) _menhir_cell1_term_variable, _menhir_box_program) _menhir_cell1_non_recursive_def, _menhir_box_program) _menhir_state
    (** State 065.
        Stack shape : LET term_variable non_recursive_def.
        Start symbol: program. *)

  | MenhirState066 : (('s, _menhir_box_program) _menhir_cell1_JUMP, _menhir_box_program) _menhir_state
    (** State 066.
        Stack shape : JUMP.
        Start symbol: program. *)

  | MenhirState067 : ((('s, _menhir_box_program) _menhir_cell1_JUMP, _menhir_box_program) _menhir_cell1_term_variable, _menhir_box_program) _menhir_state
    (** State 067.
        Stack shape : JUMP term_variable.
        Start symbol: program. *)

  | MenhirState068 : (('s, _menhir_box_program) _menhir_cell1_LBRACKET, _menhir_box_program) _menhir_state
    (** State 068.
        Stack shape : LBRACKET.
        Start symbol: program. *)

  | MenhirState072 : (((('s, _menhir_box_program) _menhir_cell1_JUMP, _menhir_box_program) _menhir_cell1_term_variable, _menhir_box_program) _menhir_cell1_list_actual_type_arguments_, _menhir_box_program) _menhir_state
    (** State 072.
        Stack shape : JUMP term_variable list(actual_type_arguments).
        Start symbol: program. *)

  | MenhirState073 : (('s, _menhir_box_program) _menhir_cell1_JOIN, _menhir_box_program) _menhir_state
    (** State 073.
        Stack shape : JOIN.
        Start symbol: program. *)

  | MenhirState074 : ((('s, _menhir_box_program) _menhir_cell1_JOIN, _menhir_box_program) _menhir_cell1_term_variable, _menhir_box_program) _menhir_state
    (** State 074.
        Stack shape : JOIN term_variable.
        Start symbol: program. *)

  | MenhirState075 : (((('s, _menhir_box_program) _menhir_cell1_JOIN, _menhir_box_program) _menhir_cell1_term_variable, _menhir_box_program) _menhir_cell1_list_formal_type_arguments_, _menhir_box_program) _menhir_state
    (** State 075.
        Stack shape : JOIN term_variable list(formal_type_arguments).
        Start symbol: program. *)

  | MenhirState076 : (('s, _menhir_box_program) _menhir_cell1_LPAR, _menhir_box_program) _menhir_state
    (** State 076.
        Stack shape : LPAR.
        Start symbol: program. *)

  | MenhirState077 : (('s, _menhir_box_program) _menhir_cell1_term_variable, _menhir_box_program) _menhir_state
    (** State 077.
        Stack shape : term_variable.
        Start symbol: program. *)

  | MenhirState080 : ((('s, _menhir_box_program) _menhir_cell1_LPAR, _menhir_box_program) _menhir_cell1_nonempty_list_term_variable_, _menhir_box_program) _menhir_state
    (** State 080.
        Stack shape : LPAR nonempty_list(term_variable).
        Start symbol: program. *)

  | MenhirState083 : (('s, _menhir_box_program) _menhir_cell1_term_arguments, _menhir_box_program) _menhir_state
    (** State 083.
        Stack shape : term_arguments.
        Start symbol: program. *)

  | MenhirState085 : ((((('s, _menhir_box_program) _menhir_cell1_JOIN, _menhir_box_program) _menhir_cell1_term_variable, _menhir_box_program) _menhir_cell1_list_formal_type_arguments_, _menhir_box_program) _menhir_cell1_list_term_arguments_, _menhir_box_program) _menhir_state
    (** State 085.
        Stack shape : JOIN term_variable list(formal_type_arguments) list(term_arguments).
        Start symbol: program. *)

  | MenhirState086 : (((('s, _menhir_box_program) _menhir_cell1_list_formal_type_arguments_, _menhir_box_program) _menhir_cell1_list_term_arguments_, _menhir_box_program) _menhir_cell1_COLON, _menhir_box_program) _menhir_state
    (** State 086.
        Stack shape : list(formal_type_arguments) list(term_arguments) COLON.
        Start symbol: program. *)

  | MenhirState089 : (((((('s, _menhir_box_program) _menhir_cell1_JOIN, _menhir_box_program) _menhir_cell1_term_variable, _menhir_box_program) _menhir_cell1_list_formal_type_arguments_, _menhir_box_program) _menhir_cell1_list_term_arguments_, _menhir_box_program) _menhir_cell1_option_preceded_COLON_typ__, _menhir_box_program) _menhir_state
    (** State 089.
        Stack shape : JOIN term_variable list(formal_type_arguments) list(term_arguments) option(preceded(COLON,typ)).
        Start symbol: program. *)

  | MenhirState090 : (('s, _menhir_box_program) _menhir_cell1_FUN, _menhir_box_program) _menhir_state
    (** State 090.
        Stack shape : FUN.
        Start symbol: program. *)

  | MenhirState092 : (('s, _menhir_box_program) _menhir_cell1_list_formal_type_arguments_, _menhir_box_program) _menhir_state
    (** State 092.
        Stack shape : list(formal_type_arguments).
        Start symbol: program. *)

  | MenhirState093 : ((('s, _menhir_box_program) _menhir_cell1_list_formal_type_arguments_, _menhir_box_program) _menhir_cell1_list_term_arguments_, _menhir_box_program) _menhir_state
    (** State 093.
        Stack shape : list(formal_type_arguments) list(term_arguments).
        Start symbol: program. *)

  | MenhirState095 : (((('s, _menhir_box_program) _menhir_cell1_list_formal_type_arguments_, _menhir_box_program) _menhir_cell1_list_term_arguments_, _menhir_box_program) _menhir_cell1_option_preceded_COLON_typ__, _menhir_box_program) _menhir_state
    (** State 095.
        Stack shape : list(formal_type_arguments) list(term_arguments) option(preceded(COLON,typ)).
        Start symbol: program. *)

  | MenhirState100 : (('s, _menhir_box_program) _menhir_cell1_loc_term1_, _menhir_box_program) _menhir_state
    (** State 100.
        Stack shape : loc(term1).
        Start symbol: program. *)

  | MenhirState103 : (('s, _menhir_box_program) _menhir_cell1_data_constructor, _menhir_box_program) _menhir_state
    (** State 103.
        Stack shape : data_constructor.
        Start symbol: program. *)

  | MenhirState105 : ((('s, _menhir_box_program) _menhir_cell1_data_constructor, _menhir_box_program) _menhir_cell1_list_actual_type_arguments_, _menhir_box_program) _menhir_state
    (** State 105.
        Stack shape : data_constructor list(actual_type_arguments).
        Start symbol: program. *)

  | MenhirState111 : (('s, _menhir_box_program) _menhir_cell1_loc_term_, _menhir_box_program) _menhir_state
    (** State 111.
        Stack shape : loc(term).
        Start symbol: program. *)

  | MenhirState114 : (('s, _menhir_box_program) _menhir_cell1_actual_type_arguments, _menhir_box_program) _menhir_state
    (** State 114.
        Stack shape : actual_type_arguments.
        Start symbol: program. *)

  | MenhirState118 : (('s, _menhir_box_program) _menhir_cell1_formal_type_arguments, _menhir_box_program) _menhir_state
    (** State 118.
        Stack shape : formal_type_arguments.
        Start symbol: program. *)

  | MenhirState122 : ((((((('s, _menhir_box_program) _menhir_cell1_JOIN, _menhir_box_program) _menhir_cell1_term_variable, _menhir_box_program) _menhir_cell1_list_formal_type_arguments_, _menhir_box_program) _menhir_cell1_list_term_arguments_, _menhir_box_program) _menhir_cell1_option_preceded_COLON_typ__, _menhir_box_program) _menhir_cell1_loc_term_, _menhir_box_program) _menhir_state
    (** State 122.
        Stack shape : JOIN term_variable list(formal_type_arguments) list(term_arguments) option(preceded(COLON,typ)) loc(term).
        Start symbol: program. *)

  | MenhirState126 : ((((('s, _menhir_box_program) _menhir_cell1_JUMP, _menhir_box_program) _menhir_cell1_term_variable, _menhir_box_program) _menhir_cell1_list_actual_type_arguments_, _menhir_box_program) _menhir_cell1_semi_loc_term__ _menhir_cell0_RBRACE, _menhir_box_program) _menhir_state
    (** State 126.
        Stack shape : JUMP term_variable list(actual_type_arguments) semi(loc(term)) RBRACE.
        Start symbol: program. *)

  | MenhirState132 : ((('s, _menhir_box_program) _menhir_cell1_LPAR, _menhir_box_program) _menhir_cell1_loc_term_, _menhir_box_program) _menhir_state
    (** State 132.
        Stack shape : LPAR loc(term).
        Start symbol: program. *)

  | MenhirState136 : ((('s, _menhir_box_program) _menhir_cell1_MATCH, _menhir_box_program) _menhir_cell1_loc_term_, _menhir_box_program) _menhir_state
    (** State 136.
        Stack shape : MATCH loc(term).
        Start symbol: program. *)

  | MenhirState138 : (((('s, _menhir_box_program) _menhir_cell1_MATCH, _menhir_box_program) _menhir_cell1_loc_term_, _menhir_box_program) _menhir_cell1_typ, _menhir_box_program) _menhir_state
    (** State 138.
        Stack shape : MATCH loc(term) typ.
        Start symbol: program. *)

  | MenhirState139 : (('s, _menhir_box_program) _menhir_cell1_BAR, _menhir_box_program) _menhir_state
    (** State 139.
        Stack shape : BAR.
        Start symbol: program. *)

  | MenhirState141 : (('s, _menhir_box_program) _menhir_cell1_pattern, _menhir_box_program) _menhir_state
    (** State 141.
        Stack shape : pattern.
        Start symbol: program. *)

  | MenhirState143 : (('s, _menhir_box_program) _menhir_cell1_data_constructor, _menhir_box_program) _menhir_state
    (** State 143.
        Stack shape : data_constructor.
        Start symbol: program. *)

  | MenhirState145 : ((('s, _menhir_box_program) _menhir_cell1_data_constructor, _menhir_box_program) _menhir_cell1_list_formal_type_arguments_, _menhir_box_program) _menhir_state
    (** State 145.
        Stack shape : data_constructor list(formal_type_arguments).
        Start symbol: program. *)

  | MenhirState147 : (('s, _menhir_box_program) _menhir_cell1_term_variable, _menhir_box_program) _menhir_state
    (** State 147.
        Stack shape : term_variable.
        Start symbol: program. *)

  | MenhirState154 : ((('s, _menhir_box_program) _menhir_cell1_BAR, _menhir_box_program) _menhir_cell1_clause, _menhir_box_program) _menhir_state
    (** State 154.
        Stack shape : BAR clause.
        Start symbol: program. *)

  | MenhirState159 : (('s, _menhir_box_program) _menhir_cell1_clause, _menhir_box_program) _menhir_state
    (** State 159.
        Stack shape : clause.
        Start symbol: program. *)


and ('s, 'r) _menhir_cell1_actual_type_arguments = 
  | MenhirCell1_actual_type_arguments of 's * ('s, 'r) _menhir_state * (Syntax.ftype list) * Lexing.position

and ('s, 'r) _menhir_cell1_clause = 
  | MenhirCell1_clause of 's * ('s, 'r) _menhir_state * (Syntax.clause)

and ('s, 'r) _menhir_cell1_data_constructor = 
  | MenhirCell1_data_constructor of 's * ('s, 'r) _menhir_state * (Identifier.t) * Lexing.position

and ('s, 'r) _menhir_cell1_formal_type_arguments = 
  | MenhirCell1_formal_type_arguments of 's * ('s, 'r) _menhir_state * (Identifier.t list)

and ('s, 'r) _menhir_cell1_list_actual_type_arguments_ = 
  | MenhirCell1_list_actual_type_arguments_ of 's * ('s, 'r) _menhir_state * (Syntax.ftype list list)

and ('s, 'r) _menhir_cell1_list_formal_type_arguments_ = 
  | MenhirCell1_list_formal_type_arguments_ of 's * ('s, 'r) _menhir_state * (Identifier.t list list)

and ('s, 'r) _menhir_cell1_list_signature_item_ = 
  | MenhirCell1_list_signature_item_ of 's * ('s, 'r) _menhir_state * (Syntax.signature_item list)

and ('s, 'r) _menhir_cell1_list_term_arguments_ = 
  | MenhirCell1_list_term_arguments_ of 's * ('s, 'r) _menhir_state * ((Identifier.t * Syntax.ftype) list list)

and ('s, 'r) _menhir_cell1_list_type_variable_ = 
  | MenhirCell1_list_type_variable_ of 's * ('s, 'r) _menhir_state * (Identifier.t list)

and ('s, 'r) _menhir_cell1_loc_term_ = 
  | MenhirCell1_loc_term_ of 's * ('s, 'r) _menhir_state * (Syntax.fterm) * Lexing.position

and ('s, 'r) _menhir_cell1_loc_term1_ = 
  | MenhirCell1_loc_term1_ of 's * ('s, 'r) _menhir_state * (Syntax.fterm) * Lexing.position

and 's _menhir_cell0_loption_quantifiers_ = 
  | MenhirCell0_loption_quantifiers_ of 's * (Identifier.t list)

and ('s, 'r) _menhir_cell1_non_recursive_def = 
  | MenhirCell1_non_recursive_def of 's * ('s, 'r) _menhir_state * (Syntax.fterm) * Lexing.position

and ('s, 'r) _menhir_cell1_nonempty_list_term_variable_ = 
  | MenhirCell1_nonempty_list_term_variable_ of 's * ('s, 'r) _menhir_state * (Identifier.t list)

and ('s, 'r) _menhir_cell1_option_preceded_COLON_typ__ = 
  | MenhirCell1_option_preceded_COLON_typ__ of 's * ('s, 'r) _menhir_state * (Syntax.ftype option)

and ('s, 'r) _menhir_cell1_pattern = 
  | MenhirCell1_pattern of 's * ('s, 'r) _menhir_state * (Syntax.pattern)

and ('s, 'r) _menhir_cell1_semi_loc_term__ = 
  | MenhirCell1_semi_loc_term__ of 's * ('s, 'r) _menhir_state * (Syntax.fterm list)

and ('s, 'r) _menhir_cell1_semi_typ_ = 
  | MenhirCell1_semi_typ_ of 's * ('s, 'r) _menhir_state * (Syntax.ftype list)

and ('s, 'r) _menhir_cell1_signature_item = 
  | MenhirCell1_signature_item of 's * ('s, 'r) _menhir_state * (Syntax.signature_item)

and ('s, 'r) _menhir_cell1_term_arguments = 
  | MenhirCell1_term_arguments of 's * ('s, 'r) _menhir_state * ((Identifier.t * Syntax.ftype) list)

and ('s, 'r) _menhir_cell1_term_variable = 
  | MenhirCell1_term_variable of 's * ('s, 'r) _menhir_state * (Identifier.t) * Lexing.position * Lexing.position

and ('s, 'r) _menhir_cell1_typ = 
  | MenhirCell1_typ of 's * ('s, 'r) _menhir_state * (Syntax.ftype) * Lexing.position

and ('s, 'r) _menhir_cell1_typ0 = 
  | MenhirCell1_typ0 of 's * ('s, 'r) _menhir_state * (Syntax.ftype) * Lexing.position

and ('s, 'r) _menhir_cell1_typ1 = 
  | MenhirCell1_typ1 of 's * ('s, 'r) _menhir_state * (Syntax.ftype) * Lexing.position

and ('s, 'r) _menhir_cell1_type_constructor = 
  | MenhirCell1_type_constructor of 's * ('s, 'r) _menhir_state * (Identifier.t)

and ('s, 'r) _menhir_cell1_type_variable = 
  | MenhirCell1_type_variable of 's * ('s, 'r) _menhir_state * (Identifier.t)

and ('s, 'r) _menhir_cell1_BAR = 
  | MenhirCell1_BAR of 's * ('s, 'r) _menhir_state

and ('s, 'r) _menhir_cell1_COLON = 
  | MenhirCell1_COLON of 's * ('s, 'r) _menhir_state

and ('s, 'r) _menhir_cell1_DATA = 
  | MenhirCell1_DATA of 's * ('s, 'r) _menhir_state

and ('s, 'r) _menhir_cell1_FORALL = 
  | MenhirCell1_FORALL of 's * ('s, 'r) _menhir_state

and ('s, 'r) _menhir_cell1_FUN = 
  | MenhirCell1_FUN of 's * ('s, 'r) _menhir_state * Lexing.position

and ('s, 'r) _menhir_cell1_IDENTIFIER = 
  | MenhirCell1_IDENTIFIER of 's * ('s, 'r) _menhir_state * (
# 41 "parser.mly"
       (string * Lexing.position * Lexing.position)
# 500 "parser.ml"
) * Lexing.position * Lexing.position

and ('s, 'r) _menhir_cell1_JOIN = 
  | MenhirCell1_JOIN of 's * ('s, 'r) _menhir_state * Lexing.position

and ('s, 'r) _menhir_cell1_JUMP = 
  | MenhirCell1_JUMP of 's * ('s, 'r) _menhir_state * Lexing.position

and ('s, 'r) _menhir_cell1_LBRACKET = 
  | MenhirCell1_LBRACKET of 's * ('s, 'r) _menhir_state

and ('s, 'r) _menhir_cell1_LET = 
  | MenhirCell1_LET of 's * ('s, 'r) _menhir_state * Lexing.position

and ('s, 'r) _menhir_cell1_LPAR = 
  | MenhirCell1_LPAR of 's * ('s, 'r) _menhir_state * Lexing.position

and ('s, 'r) _menhir_cell1_MATCH = 
  | MenhirCell1_MATCH of 's * ('s, 'r) _menhir_state * Lexing.position

and 's _menhir_cell0_RBRACE = 
  | MenhirCell0_RBRACE of 's * Lexing.position

and ('s, 'r) _menhir_cell1_TYPE = 
  | MenhirCell1_TYPE of 's * ('s, 'r) _menhir_state

and _menhir_box_program = 
  | MenhirBox_program of (Syntax.program) [@@unboxed]

let _menhir_action_01 =
  fun tys ->
    (
# 176 "parser.mly"
    ( [ tys ] )
# 535 "parser.ml"
     : (Syntax.ftype list))

let _menhir_action_02 =
  fun () ->
    (
# 70 "parser.mly"
    ( [] )
# 543 "parser.ml"
     : (Syntax.clause list))

let _menhir_action_03 =
  fun xs ->
    (
# 73 "parser.mly"
    ( xs )
# 551 "parser.ml"
     : (Syntax.clause list))

let _menhir_action_04 =
  fun xs ->
    (
# 73 "parser.mly"
    ( xs )
# 559 "parser.ml"
     : (Syntax.clause list))

let _menhir_action_05 =
  fun p t ->
    (
# 269 "parser.mly"
    ( SynClause (p, t) )
# 567 "parser.ml"
     : (Syntax.clause))

let _menhir_action_06 =
  fun id ->
    (
# 96 "parser.mly"
    ( Identifier.mak data_sort id )
# 575 "parser.ml"
     : (Identifier.t))

let _menhir_action_07 =
  fun d s ->
    (
# 145 "parser.mly"
    ( SynDatacon (d, s) )
# 583 "parser.ml"
     : (Syntax.signature_item))

let _menhir_action_08 =
  fun def ->
    (
# 206 "parser.mly"
    ( def )
# 591 "parser.ml"
     : (Syntax.fterm))

let _menhir_action_09 =
  fun tvar ->
    (
# 172 "parser.mly"
    ( [ tvar ] )
# 599 "parser.ml"
     : (Identifier.t list))

let _menhir_action_10 =
  fun () ->
    (
# 216 "<standard.mly>"
    ( [] )
# 607 "parser.ml"
     : (Syntax.ftype list list))

let _menhir_action_11 =
  fun x xs ->
    (
# 219 "<standard.mly>"
    ( x :: xs )
# 615 "parser.ml"
     : (Syntax.ftype list list))

let _menhir_action_12 =
  fun () ->
    (
# 216 "<standard.mly>"
    ( [] )
# 623 "parser.ml"
     : (Identifier.t list list))

let _menhir_action_13 =
  fun x xs ->
    (
# 219 "<standard.mly>"
    ( x :: xs )
# 631 "parser.ml"
     : (Identifier.t list list))

let _menhir_action_14 =
  fun () ->
    (
# 216 "<standard.mly>"
    ( [] )
# 639 "parser.ml"
     : (Syntax.signature_item list))

let _menhir_action_15 =
  fun x xs ->
    (
# 219 "<standard.mly>"
    ( x :: xs )
# 647 "parser.ml"
     : (Syntax.signature_item list))

let _menhir_action_16 =
  fun () ->
    (
# 216 "<standard.mly>"
    ( [] )
# 655 "parser.ml"
     : ((Identifier.t * Syntax.ftype) list list))

let _menhir_action_17 =
  fun x xs ->
    (
# 219 "<standard.mly>"
    ( x :: xs )
# 663 "parser.ml"
     : ((Identifier.t * Syntax.ftype) list list))

let _menhir_action_18 =
  fun () ->
    (
# 216 "<standard.mly>"
    ( [] )
# 671 "parser.ml"
     : (Syntax.ftype list))

let _menhir_action_19 =
  fun x xs ->
    (
# 219 "<standard.mly>"
    ( x :: xs )
# 679 "parser.ml"
     : (Syntax.ftype list))

let _menhir_action_20 =
  fun () ->
    (
# 216 "<standard.mly>"
    ( [] )
# 687 "parser.ml"
     : (Identifier.t list))

let _menhir_action_21 =
  fun x xs ->
    (
# 219 "<standard.mly>"
    ( x :: xs )
# 695 "parser.ml"
     : (Identifier.t list))

let _menhir_action_22 =
  fun _endpos_t_ _startpos_t_ t ->
    let _endpos = _endpos_t_ in
    let _startpos = _startpos_t_ in
    (
# 281 "parser.mly"
    ( SynTeLoc ((_startpos, _endpos), t) )
# 705 "parser.ml"
     : (Syntax.fterm))

let _menhir_action_23 =
  fun _endpos_t_ _startpos_t_ t ->
    let _endpos = _endpos_t_ in
    let _startpos = _startpos_t_ in
    (
# 281 "parser.mly"
    ( SynTeLoc ((_startpos, _endpos), t) )
# 715 "parser.ml"
     : (Syntax.fterm))

let _menhir_action_24 =
  fun _endpos_t_ _startpos_t_ t ->
    let _endpos = _endpos_t_ in
    let _startpos = _startpos_t_ in
    (
# 281 "parser.mly"
    ( SynTeLoc ((_startpos, _endpos), t) )
# 725 "parser.ml"
     : (Syntax.fterm))

let _menhir_action_25 =
  fun () ->
    (
# 145 "<standard.mly>"
    ( [] )
# 733 "parser.ml"
     : (Identifier.t list))

let _menhir_action_26 =
  fun x ->
    (
# 148 "<standard.mly>"
    ( x )
# 741 "parser.ml"
     : (Identifier.t list))

let _menhir_action_27 =
  fun codomain t xs xs_inlined1 ->
    let te_args =
      let xs = xs_inlined1 in
      
# 184 "parser.mly"
    ( concat xs )
# 751 "parser.ml"
      
    in
    let ty_args = 
# 184 "parser.mly"
    ( concat xs )
# 757 "parser.ml"
     in
    (
# 202 "parser.mly"
    ( make_non_recursive_definition ty_args te_args codomain t )
# 762 "parser.ml"
     : (Syntax.fterm))

let _menhir_action_28 =
  fun x ->
    let x = 
# 188 "<standard.mly>"
    ( x )
# 770 "parser.ml"
     in
    (
# 228 "<standard.mly>"
    ( [ x ] )
# 775 "parser.ml"
     : (Syntax.clause list))

let _menhir_action_29 =
  fun x xs ->
    let x = 
# 188 "<standard.mly>"
    ( x )
# 783 "parser.ml"
     in
    (
# 231 "<standard.mly>"
    ( x :: xs )
# 788 "parser.ml"
     : (Syntax.clause list))

let _menhir_action_30 =
  fun x ->
    (
# 228 "<standard.mly>"
    ( [ x ] )
# 796 "parser.ml"
     : (Identifier.t list))

let _menhir_action_31 =
  fun x xs ->
    (
# 231 "<standard.mly>"
    ( x :: xs )
# 804 "parser.ml"
     : (Identifier.t list))

let _menhir_action_32 =
  fun x ->
    let x = 
# 196 "<standard.mly>"
    ( x )
# 812 "parser.ml"
     in
    (
# 228 "<standard.mly>"
    ( [ x ] )
# 817 "parser.ml"
     : (Syntax.fterm list))

let _menhir_action_33 =
  fun x xs ->
    let x = 
# 196 "<standard.mly>"
    ( x )
# 825 "parser.ml"
     in
    (
# 231 "<standard.mly>"
    ( x :: xs )
# 830 "parser.ml"
     : (Syntax.fterm list))

let _menhir_action_34 =
  fun x ->
    let x = 
# 196 "<standard.mly>"
    ( x )
# 838 "parser.ml"
     in
    (
# 228 "<standard.mly>"
    ( [ x ] )
# 843 "parser.ml"
     : (Identifier.t list))

let _menhir_action_35 =
  fun x xs ->
    let x = 
# 196 "<standard.mly>"
    ( x )
# 851 "parser.ml"
     in
    (
# 231 "<standard.mly>"
    ( x :: xs )
# 856 "parser.ml"
     : (Identifier.t list))

let _menhir_action_36 =
  fun x ->
    let x = 
# 196 "<standard.mly>"
    ( x )
# 864 "parser.ml"
     in
    (
# 228 "<standard.mly>"
    ( [ x ] )
# 869 "parser.ml"
     : (Syntax.ftype list))

let _menhir_action_37 =
  fun x xs ->
    let x = 
# 196 "<standard.mly>"
    ( x )
# 877 "parser.ml"
     in
    (
# 231 "<standard.mly>"
    ( x :: xs )
# 882 "parser.ml"
     : (Syntax.ftype list))

let _menhir_action_38 =
  fun x ->
    (
# 228 "<standard.mly>"
    ( [ x ] )
# 890 "parser.ml"
     : (Syntax.ftype list))

let _menhir_action_39 =
  fun x xs ->
    (
# 231 "<standard.mly>"
    ( x :: xs )
# 898 "parser.ml"
     : (Syntax.ftype list))

let _menhir_action_40 =
  fun () ->
    (
# 111 "<standard.mly>"
    ( None )
# 906 "parser.ml"
     : (Syntax.ftype option))

let _menhir_action_41 =
  fun x ->
    let x = 
# 188 "<standard.mly>"
    ( x )
# 914 "parser.ml"
     in
    (
# 114 "<standard.mly>"
    ( Some x )
# 919 "parser.ml"
     : (Syntax.ftype option))

let _menhir_action_42 =
  fun _endpos__5_ _startpos_d_ d fields xs ->
    let tvars = 
# 184 "parser.mly"
    ( concat xs )
# 927 "parser.ml"
     in
    let _endpos = _endpos__5_ in
    let _startpos = _startpos_d_ in
    (
# 273 "parser.mly"
    ( SynPatData ((_startpos, _endpos), d, tvars, fields) )
# 934 "parser.ml"
     : (Syntax.pattern))

let _menhir_action_43 =
  fun ds t ->
    (
# 294 "parser.mly"
    ( SynProg (ds, t) )
# 942 "parser.ml"
     : (Syntax.program))

let _menhir_action_44 =
  fun tvars ->
    (
# 135 "parser.mly"
    ( tvars )
# 950 "parser.ml"
     : (Identifier.t list))

let _menhir_action_45 =
  fun fields params tc tvars ->
    (
# 141 "parser.mly"
    ( SynScheme (tvars, fields, tc, params) )
# 958 "parser.ml"
     : (Syntax.scheme))

let _menhir_action_46 =
  fun () ->
    (
# 58 "parser.mly"
    ( [] )
# 966 "parser.ml"
     : (Syntax.fterm list))

let _menhir_action_47 =
  fun xs ->
    (
# 61 "parser.mly"
    ( xs )
# 974 "parser.ml"
     : (Syntax.fterm list))

let _menhir_action_48 =
  fun xs ->
    (
# 61 "parser.mly"
    ( xs )
# 982 "parser.ml"
     : (Syntax.fterm list))

let _menhir_action_49 =
  fun () ->
    (
# 58 "parser.mly"
    ( [] )
# 990 "parser.ml"
     : (Identifier.t list))

let _menhir_action_50 =
  fun xs ->
    (
# 61 "parser.mly"
    ( xs )
# 998 "parser.ml"
     : (Identifier.t list))

let _menhir_action_51 =
  fun xs ->
    (
# 61 "parser.mly"
    ( xs )
# 1006 "parser.ml"
     : (Identifier.t list))

let _menhir_action_52 =
  fun () ->
    (
# 58 "parser.mly"
    ( [] )
# 1014 "parser.ml"
     : (Syntax.ftype list))

let _menhir_action_53 =
  fun xs ->
    (
# 61 "parser.mly"
    ( xs )
# 1022 "parser.ml"
     : (Syntax.ftype list))

let _menhir_action_54 =
  fun xs ->
    (
# 61 "parser.mly"
    ( xs )
# 1030 "parser.ml"
     : (Syntax.ftype list))

let _menhir_action_55 =
  fun x ->
    (
# 250 "<standard.mly>"
    ( [ x ] )
# 1038 "parser.ml"
     : (Syntax.clause list))

let _menhir_action_56 =
  fun x xs ->
    (
# 253 "<standard.mly>"
    ( x :: xs )
# 1046 "parser.ml"
     : (Syntax.clause list))

let _menhir_action_57 =
  fun x ->
    (
# 250 "<standard.mly>"
    ( [ x ] )
# 1054 "parser.ml"
     : (Syntax.fterm list))

let _menhir_action_58 =
  fun x xs ->
    (
# 253 "<standard.mly>"
    ( x :: xs )
# 1062 "parser.ml"
     : (Syntax.fterm list))

let _menhir_action_59 =
  fun x ->
    (
# 250 "<standard.mly>"
    ( [ x ] )
# 1070 "parser.ml"
     : (Identifier.t list))

let _menhir_action_60 =
  fun x xs ->
    (
# 253 "<standard.mly>"
    ( x :: xs )
# 1078 "parser.ml"
     : (Identifier.t list))

let _menhir_action_61 =
  fun x ->
    (
# 250 "<standard.mly>"
    ( [ x ] )
# 1086 "parser.ml"
     : (Syntax.ftype list))

let _menhir_action_62 =
  fun x xs ->
    (
# 253 "<standard.mly>"
    ( x :: xs )
# 1094 "parser.ml"
     : (Syntax.ftype list))

let _menhir_action_63 =
  fun d ->
    (
# 290 "parser.mly"
    ( d )
# 1102 "parser.ml"
     : (Syntax.signature_item))

let _menhir_action_64 =
  fun d ->
    (
# 290 "parser.mly"
    ( d )
# 1110 "parser.ml"
     : (Syntax.signature_item))

let _menhir_action_65 =
  fun t ->
    (
# 236 "parser.mly"
    ( t )
# 1118 "parser.ml"
     : (Syntax.fterm))

let _menhir_action_66 =
  fun def ->
    (
# 238 "parser.mly"
    ( def )
# 1126 "parser.ml"
     : (Syntax.fterm))

let _menhir_action_67 =
  fun codomain j t1 t2 xs xs_inlined1 ->
    let te_args =
      let xs = xs_inlined1 in
      
# 184 "parser.mly"
    ( concat xs )
# 1136 "parser.ml"
      
    in
    let ty_args = 
# 184 "parser.mly"
    ( concat xs )
# 1142 "parser.ml"
     in
    (
# 244 "parser.mly"
  (
    let t1_annotated = otyannot t1 codomain in
    SynTeJoin (j, ty_args, te_args, t1_annotated, t2)
  )
# 1150 "parser.ml"
     : (Syntax.fterm))

let _menhir_action_68 =
  fun def f t ->
    (
# 260 "parser.mly"
    ( SynTeLet (f, def, t) )
# 1158 "parser.ml"
     : (Syntax.fterm))

let _menhir_action_69 =
  fun x ->
    (
# 214 "parser.mly"
    ( SynTeVar x )
# 1166 "parser.ml"
     : (Syntax.fterm))

let _menhir_action_70 =
  fun d fields xs ->
    let tys = 
# 184 "parser.mly"
    ( concat xs )
# 1174 "parser.ml"
     in
    (
# 216 "parser.mly"
    ( SynTeData (d, tys, fields) )
# 1179 "parser.ml"
     : (Syntax.fterm))

let _menhir_action_71 =
  fun args j ret_ty xs ->
    let tys = 
# 184 "parser.mly"
    ( concat xs )
# 1187 "parser.ml"
     in
    (
# 218 "parser.mly"
    ( SynTeJump (j, tys, args, ret_ty) )
# 1192 "parser.ml"
     : (Syntax.fterm))

let _menhir_action_72 =
  fun t ->
    (
# 220 "parser.mly"
    ( t )
# 1200 "parser.ml"
     : (Syntax.fterm))

let _menhir_action_73 =
  fun t ty ->
    (
# 222 "parser.mly"
    ( SynTeTyAnnot (t, ty) )
# 1208 "parser.ml"
     : (Syntax.fterm))

let _menhir_action_74 =
  fun cs t ty ->
    (
# 224 "parser.mly"
    ( SynTeMatch (t, ty, cs) )
# 1216 "parser.ml"
     : (Syntax.fterm))

let _menhir_action_75 =
  fun t ->
    (
# 228 "parser.mly"
    ( t )
# 1224 "parser.ml"
     : (Syntax.fterm))

let _menhir_action_76 =
  fun t1 t2 ->
    (
# 230 "parser.mly"
    ( SynTeApp (t1, t2) )
# 1232 "parser.ml"
     : (Syntax.fterm))

let _menhir_action_77 =
  fun t tys ->
    (
# 232 "parser.mly"
    ( tyapp t tys )
# 1240 "parser.ml"
     : (Syntax.fterm))

let _menhir_action_78 =
  fun domain xs ->
    (
# 180 "parser.mly"
    ( distribute xs domain )
# 1248 "parser.ml"
     : ((Identifier.t * Syntax.ftype) list))

let _menhir_action_79 =
  fun id ->
    (
# 88 "parser.mly"
    ( Identifier.mak term_sort id )
# 1256 "parser.ml"
     : (Identifier.t))

let _menhir_action_80 =
  fun ty ->
    (
# 123 "parser.mly"
    ( ty )
# 1264 "parser.ml"
     : (Syntax.ftype))

let _menhir_action_81 =
  fun ty1 ty2 ->
    (
# 125 "parser.mly"
    ( SynTyArrow (ty1, ty2) )
# 1272 "parser.ml"
     : (Syntax.ftype))

let _menhir_action_82 =
  fun tvars ty ->
    (
# 127 "parser.mly"
    ( forall tvars ty )
# 1280 "parser.ml"
     : (Syntax.ftype))

let _menhir_action_83 =
  fun id ->
    (
# 109 "parser.mly"
    ( SynTyVarOrTyCon (id, []) )
# 1288 "parser.ml"
     : (Syntax.ftype))

let _menhir_action_84 =
  fun ty ->
    (
# 111 "parser.mly"
    ( ty )
# 1296 "parser.ml"
     : (Syntax.ftype))

let _menhir_action_85 =
  fun id params ->
    (
# 117 "parser.mly"
    ( SynTyVarOrTyCon (id, params) )
# 1304 "parser.ml"
     : (Syntax.ftype))

let _menhir_action_86 =
  fun ty ->
    (
# 119 "parser.mly"
    ( ty )
# 1312 "parser.ml"
     : (Syntax.ftype))

let _menhir_action_87 =
  fun id ->
    (
# 100 "parser.mly"
    ( Identifier.mak typecon_sort id )
# 1320 "parser.ml"
     : (Identifier.t))

let _menhir_action_88 =
  fun params tc ->
    (
# 153 "parser.mly"
    ( SynType (tc, params) )
# 1328 "parser.ml"
     : (Syntax.signature_item))

let _menhir_action_89 =
  fun id ->
    (
# 92 "parser.mly"
    ( Identifier.mak type_sort id )
# 1336 "parser.ml"
     : (Identifier.t))

let _menhir_print_token : token -> string =
  fun _tok ->
    match _tok with
    | ARROW ->
        "ARROW"
    | BAR ->
        "BAR"
    | COLON ->
        "COLON"
    | CONSTRUCTOR ->
        "CONSTRUCTOR"
    | DATA ->
        "DATA"
    | DOT ->
        "DOT"
    | END ->
        "END"
    | EOF ->
        "EOF"
    | EQ ->
        "EQ"
    | FORALL ->
        "FORALL"
    | FUN ->
        "FUN"
    | IDENTIFIER _ ->
        "IDENTIFIER"
    | IN ->
        "IN"
    | JOIN ->
        "JOIN"
    | JUMP ->
        "JUMP"
    | LBRACE ->
        "LBRACE"
    | LBRACKET ->
        "LBRACKET"
    | LET ->
        "LET"
    | LPAR ->
        "LPAR"
    | MATCH ->
        "MATCH"
    | PROGRAM ->
        "PROGRAM"
    | RBRACE ->
        "RBRACE"
    | RBRACKET ->
        "RBRACKET"
    | RETURN ->
        "RETURN"
    | RPAR ->
        "RPAR"
    | SEMI ->
        "SEMI"
    | TAG _ ->
        "TAG"
    | TYPE ->
        "TYPE"
    | WITH ->
        "WITH"

let _menhir_fail : unit -> 'a =
  fun () ->
    Printf.eprintf "Internal failure -- please contact the parser generator's developers.\n%!";
    assert false

include struct
  
  [@@@ocaml.warning "-4-37"]
  
  let _menhir_run_163 : type  ttv_stack. (ttv_stack, _menhir_box_program) _menhir_cell1_list_signature_item_ -> _ -> _ -> _menhir_box_program =
    fun _menhir_stack _v _tok ->
      match (_tok : MenhirBasics.token) with
      | EOF ->
          let MenhirCell1_list_signature_item_ (_menhir_stack, _, ds) = _menhir_stack in
          let t = _v in
          let _v = _menhir_action_43 ds t in
          MenhirBox_program _v
      | _ ->
          _eRR ()
  
  let rec _menhir_run_001 : type  ttv_stack. ttv_stack -> _ -> _ -> (ttv_stack, _menhir_box_program) _menhir_state -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s ->
      let _menhir_stack = MenhirCell1_TYPE (_menhir_stack, _menhir_s) in
      let _menhir_s = MenhirState001 in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | IDENTIFIER _v ->
          _menhir_run_002 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s
      | _ ->
          _eRR ()
  
  and _menhir_run_002 : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_program) _menhir_state -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s ->
      let _tok = _menhir_lexer _menhir_lexbuf in
      let id = _v in
      let _v = _menhir_action_87 id in
      _menhir_goto_type_constructor _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
  
  and _menhir_goto_type_constructor : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_program) _menhir_state -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      match _menhir_s with
      | MenhirState043 ->
          _menhir_run_044 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState001 ->
          _menhir_run_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | _ ->
          _menhir_fail ()
  
  and _menhir_run_044 : type  ttv_stack. ((((ttv_stack, _menhir_box_program) _menhir_cell1_DATA, _menhir_box_program) _menhir_cell1_data_constructor _menhir_cell0_loption_quantifiers_, _menhir_box_program) _menhir_cell1_semi_typ_ _menhir_cell0_RBRACE as 'stack) -> _ -> _ -> _ -> ('stack, _menhir_box_program) _menhir_state -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      let _menhir_stack = MenhirCell1_type_constructor (_menhir_stack, _menhir_s, _v) in
      match (_tok : MenhirBasics.token) with
      | LPAR ->
          _menhir_run_020 _menhir_stack _menhir_lexbuf _menhir_lexer MenhirState044
      | IDENTIFIER _v_0 ->
          _menhir_run_022 _menhir_stack _menhir_lexbuf _menhir_lexer _v_0 MenhirState044
      | DATA | PROGRAM | TYPE ->
          let _v_1 = _menhir_action_18 () in
          _menhir_run_047 _menhir_stack _menhir_lexbuf _menhir_lexer _v_1 _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_020 : type  ttv_stack. ttv_stack -> _ -> _ -> (ttv_stack, _menhir_box_program) _menhir_state -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s ->
      let _startpos = _menhir_lexbuf.Lexing.lex_start_p in
      let _menhir_stack = MenhirCell1_LPAR (_menhir_stack, _menhir_s, _startpos) in
      let _menhir_s = MenhirState020 in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | LPAR ->
          _menhir_run_020 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
      | IDENTIFIER _v ->
          _menhir_run_021 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s
      | FORALL ->
          _menhir_run_026 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
      | _ ->
          _eRR ()
  
  and _menhir_run_021 : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_program) _menhir_state -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s ->
      let _startpos = _menhir_lexbuf.Lexing.lex_start_p in
      let _endpos = _menhir_lexbuf.Lexing.lex_curr_p in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | LPAR ->
          let _menhir_stack = MenhirCell1_IDENTIFIER (_menhir_stack, _menhir_s, _v, _startpos, _endpos) in
          _menhir_run_020 _menhir_stack _menhir_lexbuf _menhir_lexer MenhirState021
      | IDENTIFIER _v_0 ->
          let _menhir_stack = MenhirCell1_IDENTIFIER (_menhir_stack, _menhir_s, _v, _startpos, _endpos) in
          _menhir_run_022 _menhir_stack _menhir_lexbuf _menhir_lexer _v_0 MenhirState021
      | ARROW | BAR | COLON | END | EOF | EQ | IN | JUMP | LBRACKET | MATCH | RBRACE | RBRACKET | RETURN | RPAR | SEMI | TAG _ | WITH ->
          let (_endpos_id_, id) = (_endpos, _v) in
          let _v = _menhir_action_83 id in
          _menhir_goto_typ0 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos_id_ _v _menhir_s _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_022 : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_program) _menhir_state -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s ->
      let _endpos = _menhir_lexbuf.Lexing.lex_curr_p in
      let _tok = _menhir_lexer _menhir_lexbuf in
      let (_endpos_id_, id) = (_endpos, _v) in
      let _v = _menhir_action_83 id in
      _menhir_goto_typ0 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos_id_ _v _menhir_s _tok
  
  and _menhir_goto_typ0 : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> _ -> (ttv_stack, _menhir_box_program) _menhir_state -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _v _menhir_s _tok ->
      match _menhir_s with
      | MenhirState045 ->
          _menhir_run_045 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _v _menhir_s _tok
      | MenhirState044 ->
          _menhir_run_045 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _v _menhir_s _tok
      | MenhirState136 ->
          _menhir_run_031 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _v _menhir_s _tok
      | MenhirState132 ->
          _menhir_run_031 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _v _menhir_s _tok
      | MenhirState126 ->
          _menhir_run_031 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _v _menhir_s _tok
      | MenhirState086 ->
          _menhir_run_031 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _v _menhir_s _tok
      | MenhirState080 ->
          _menhir_run_031 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _v _menhir_s _tok
      | MenhirState068 ->
          _menhir_run_031 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _v _menhir_s _tok
      | MenhirState037 ->
          _menhir_run_031 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _v _menhir_s _tok
      | MenhirState019 ->
          _menhir_run_031 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _v _menhir_s _tok
      | MenhirState020 ->
          _menhir_run_031 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _v _menhir_s _tok
      | MenhirState028 ->
          _menhir_run_031 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _v _menhir_s _tok
      | MenhirState030 ->
          _menhir_run_031 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _v _menhir_s _tok
      | MenhirState023 ->
          _menhir_run_023 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _v _menhir_s _tok
      | MenhirState021 ->
          _menhir_run_023 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _v _menhir_s _tok
      | _ ->
          _menhir_fail ()
  
  and _menhir_run_045 : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> _ -> (ttv_stack, _menhir_box_program) _menhir_state -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _v _menhir_s _tok ->
      let _menhir_stack = MenhirCell1_typ0 (_menhir_stack, _menhir_s, _v, _endpos) in
      match (_tok : MenhirBasics.token) with
      | LPAR ->
          _menhir_run_020 _menhir_stack _menhir_lexbuf _menhir_lexer MenhirState045
      | IDENTIFIER _v_0 ->
          _menhir_run_022 _menhir_stack _menhir_lexbuf _menhir_lexer _v_0 MenhirState045
      | DATA | PROGRAM | TYPE ->
          let _v_1 = _menhir_action_18 () in
          _menhir_run_046 _menhir_stack _menhir_lexbuf _menhir_lexer _v_1 _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_046 : type  ttv_stack. (ttv_stack, _menhir_box_program) _menhir_cell1_typ0 -> _ -> _ -> _ -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let MenhirCell1_typ0 (_menhir_stack, _menhir_s, x, _) = _menhir_stack in
      let xs = _v in
      let _v = _menhir_action_19 x xs in
      _menhir_goto_list_typ0_ _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
  
  and _menhir_goto_list_typ0_ : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_program) _menhir_state -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      match _menhir_s with
      | MenhirState044 ->
          _menhir_run_047 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState045 ->
          _menhir_run_046 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | _ ->
          _menhir_fail ()
  
  and _menhir_run_047 : type  ttv_stack. ((((ttv_stack, _menhir_box_program) _menhir_cell1_DATA, _menhir_box_program) _menhir_cell1_data_constructor _menhir_cell0_loption_quantifiers_, _menhir_box_program) _menhir_cell1_semi_typ_ _menhir_cell0_RBRACE, _menhir_box_program) _menhir_cell1_type_constructor -> _ -> _ -> _ -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let MenhirCell1_type_constructor (_menhir_stack, _, tc) = _menhir_stack in
      let MenhirCell0_RBRACE (_menhir_stack, _) = _menhir_stack in
      let MenhirCell1_semi_typ_ (_menhir_stack, _, fields) = _menhir_stack in
      let MenhirCell0_loption_quantifiers_ (_menhir_stack, tvars) = _menhir_stack in
      let params = _v in
      let _v = _menhir_action_45 fields params tc tvars in
      let MenhirCell1_data_constructor (_menhir_stack, _, d, _) = _menhir_stack in
      let MenhirCell1_DATA (_menhir_stack, _menhir_s) = _menhir_stack in
      let s = _v in
      let _v = _menhir_action_07 d s in
      let d = _v in
      let _v = _menhir_action_63 d in
      _menhir_goto_signature_item _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
  
  and _menhir_goto_signature_item : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_program) _menhir_state -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      let _menhir_stack = MenhirCell1_signature_item (_menhir_stack, _menhir_s, _v) in
      match (_tok : MenhirBasics.token) with
      | TYPE ->
          _menhir_run_001 _menhir_stack _menhir_lexbuf _menhir_lexer MenhirState050
      | DATA ->
          _menhir_run_008 _menhir_stack _menhir_lexbuf _menhir_lexer MenhirState050
      | PROGRAM ->
          let _v_0 = _menhir_action_14 () in
          _menhir_run_051 _menhir_stack _menhir_lexbuf _menhir_lexer _v_0
      | _ ->
          _eRR ()
  
  and _menhir_run_008 : type  ttv_stack. ttv_stack -> _ -> _ -> (ttv_stack, _menhir_box_program) _menhir_state -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s ->
      let _menhir_stack = MenhirCell1_DATA (_menhir_stack, _menhir_s) in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | CONSTRUCTOR ->
          let _menhir_s = MenhirState009 in
          let _tok = _menhir_lexer _menhir_lexbuf in
          (match (_tok : MenhirBasics.token) with
          | TAG _v ->
              _menhir_run_010 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s
          | _ ->
              _eRR ())
      | _ ->
          _eRR ()
  
  and _menhir_run_010 : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_program) _menhir_state -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s ->
      let _startpos = _menhir_lexbuf.Lexing.lex_start_p in
      let _tok = _menhir_lexer _menhir_lexbuf in
      let (_startpos_id_, id) = (_startpos, _v) in
      let _v = _menhir_action_06 id in
      _menhir_goto_data_constructor _menhir_stack _menhir_lexbuf _menhir_lexer _startpos_id_ _v _menhir_s _tok
  
  and _menhir_goto_data_constructor : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> _ -> (ttv_stack, _menhir_box_program) _menhir_state -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _startpos _v _menhir_s _tok ->
      match _menhir_s with
      | MenhirState159 ->
          _menhir_run_143 _menhir_stack _menhir_lexbuf _menhir_lexer _startpos _v _menhir_s _tok
      | MenhirState138 ->
          _menhir_run_143 _menhir_stack _menhir_lexbuf _menhir_lexer _startpos _v _menhir_s _tok
      | MenhirState139 ->
          _menhir_run_143 _menhir_stack _menhir_lexbuf _menhir_lexer _startpos _v _menhir_s _tok
      | MenhirState055 ->
          _menhir_run_103 _menhir_stack _menhir_lexbuf _menhir_lexer _startpos _v _menhir_s _tok
      | MenhirState056 ->
          _menhir_run_103 _menhir_stack _menhir_lexbuf _menhir_lexer _startpos _v _menhir_s _tok
      | MenhirState141 ->
          _menhir_run_103 _menhir_stack _menhir_lexbuf _menhir_lexer _startpos _v _menhir_s _tok
      | MenhirState057 ->
          _menhir_run_103 _menhir_stack _menhir_lexbuf _menhir_lexer _startpos _v _menhir_s _tok
      | MenhirState065 ->
          _menhir_run_103 _menhir_stack _menhir_lexbuf _menhir_lexer _startpos _v _menhir_s _tok
      | MenhirState072 ->
          _menhir_run_103 _menhir_stack _menhir_lexbuf _menhir_lexer _startpos _v _menhir_s _tok
      | MenhirState089 ->
          _menhir_run_103 _menhir_stack _menhir_lexbuf _menhir_lexer _startpos _v _menhir_s _tok
      | MenhirState122 ->
          _menhir_run_103 _menhir_stack _menhir_lexbuf _menhir_lexer _startpos _v _menhir_s _tok
      | MenhirState095 ->
          _menhir_run_103 _menhir_stack _menhir_lexbuf _menhir_lexer _startpos _v _menhir_s _tok
      | MenhirState105 ->
          _menhir_run_103 _menhir_stack _menhir_lexbuf _menhir_lexer _startpos _v _menhir_s _tok
      | MenhirState111 ->
          _menhir_run_103 _menhir_stack _menhir_lexbuf _menhir_lexer _startpos _v _menhir_s _tok
      | MenhirState100 ->
          _menhir_run_103 _menhir_stack _menhir_lexbuf _menhir_lexer _startpos _v _menhir_s _tok
      | MenhirState009 ->
          _menhir_run_011 _menhir_stack _menhir_lexbuf _menhir_lexer _startpos _v _menhir_s _tok
      | _ ->
          _menhir_fail ()
  
  and _menhir_run_143 : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> _ -> (ttv_stack, _menhir_box_program) _menhir_state -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _startpos _v _menhir_s _tok ->
      let _menhir_stack = MenhirCell1_data_constructor (_menhir_stack, _menhir_s, _v, _startpos) in
      match (_tok : MenhirBasics.token) with
      | LBRACKET ->
          _menhir_run_061 _menhir_stack _menhir_lexbuf _menhir_lexer MenhirState143
      | LBRACE ->
          let _v_0 = _menhir_action_12 () in
          _menhir_run_144 _menhir_stack _menhir_lexbuf _menhir_lexer _v_0 MenhirState143 _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_061 : type  ttv_stack. ttv_stack -> _ -> _ -> (ttv_stack, _menhir_box_program) _menhir_state -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s ->
      let _menhir_stack = MenhirCell1_LBRACKET (_menhir_stack, _menhir_s) in
      let _menhir_s = MenhirState061 in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | IDENTIFIER _v ->
          _menhir_run_004 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s
      | _ ->
          _eRR ()
  
  and _menhir_run_004 : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_program) _menhir_state -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s ->
      let _tok = _menhir_lexer _menhir_lexbuf in
      let id = _v in
      let _v = _menhir_action_89 id in
      _menhir_goto_type_variable _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
  
  and _menhir_goto_type_variable : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_program) _menhir_state -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      match _menhir_s with
      | MenhirState061 ->
          _menhir_run_062 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState026 ->
          _menhir_run_005 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState013 ->
          _menhir_run_005 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState005 ->
          _menhir_run_005 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState003 ->
          _menhir_run_005 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | _ ->
          _menhir_fail ()
  
  and _menhir_run_062 : type  ttv_stack. (ttv_stack, _menhir_box_program) _menhir_cell1_LBRACKET -> _ -> _ -> _ -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      match (_tok : MenhirBasics.token) with
      | RBRACKET ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let MenhirCell1_LBRACKET (_menhir_stack, _menhir_s) = _menhir_stack in
          let tvar = _v in
          let _v = _menhir_action_09 tvar in
          let _menhir_stack = MenhirCell1_formal_type_arguments (_menhir_stack, _menhir_s, _v) in
          (match (_tok : MenhirBasics.token) with
          | LBRACKET ->
              _menhir_run_061 _menhir_stack _menhir_lexbuf _menhir_lexer MenhirState118
          | COLON | EQ | LBRACE | LPAR ->
              let _v_0 = _menhir_action_12 () in
              _menhir_run_119 _menhir_stack _menhir_lexbuf _menhir_lexer _v_0 _tok
          | _ ->
              _eRR ())
      | _ ->
          _eRR ()
  
  and _menhir_run_119 : type  ttv_stack. (ttv_stack, _menhir_box_program) _menhir_cell1_formal_type_arguments -> _ -> _ -> _ -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let MenhirCell1_formal_type_arguments (_menhir_stack, _menhir_s, x) = _menhir_stack in
      let xs = _v in
      let _v = _menhir_action_13 x xs in
      _menhir_goto_list_formal_type_arguments_ _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
  
  and _menhir_goto_list_formal_type_arguments_ : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_program) _menhir_state -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      match _menhir_s with
      | MenhirState143 ->
          _menhir_run_144 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState118 ->
          _menhir_run_119 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState060 ->
          _menhir_run_092 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState090 ->
          _menhir_run_092 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState074 ->
          _menhir_run_075 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | _ ->
          _menhir_fail ()
  
  and _menhir_run_144 : type  ttv_stack. ((ttv_stack, _menhir_box_program) _menhir_cell1_data_constructor as 'stack) -> _ -> _ -> _ -> ('stack, _menhir_box_program) _menhir_state -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      let _menhir_stack = MenhirCell1_list_formal_type_arguments_ (_menhir_stack, _menhir_s, _v) in
      match (_tok : MenhirBasics.token) with
      | LBRACE ->
          let _menhir_s = MenhirState145 in
          let _tok = _menhir_lexer _menhir_lexbuf in
          (match (_tok : MenhirBasics.token) with
          | IDENTIFIER _v ->
              _menhir_run_059 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s
          | RBRACE ->
              let _v = _menhir_action_49 () in
              _menhir_goto_semi_term_variable_ _menhir_stack _menhir_lexbuf _menhir_lexer _v
          | _ ->
              _eRR ())
      | _ ->
          _eRR ()
  
  and _menhir_run_059 : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_program) _menhir_state -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s ->
      let _startpos = _menhir_lexbuf.Lexing.lex_start_p in
      let _endpos = _menhir_lexbuf.Lexing.lex_curr_p in
      let _tok = _menhir_lexer _menhir_lexbuf in
      let (_endpos_id_, _startpos_id_, id) = (_endpos, _startpos, _v) in
      let _v = _menhir_action_79 id in
      _menhir_goto_term_variable _menhir_stack _menhir_lexbuf _menhir_lexer _endpos_id_ _startpos_id_ _v _menhir_s _tok
  
  and _menhir_goto_term_variable : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> _ -> _ -> (ttv_stack, _menhir_box_program) _menhir_state -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _startpos _v _menhir_s _tok ->
      match _menhir_s with
      | MenhirState147 ->
          _menhir_run_146 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _startpos _v _menhir_s _tok
      | MenhirState145 ->
          _menhir_run_146 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _startpos _v _menhir_s _tok
      | MenhirState055 ->
          _menhir_run_096 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _startpos _v _menhir_s _tok
      | MenhirState141 ->
          _menhir_run_096 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _startpos _v _menhir_s _tok
      | MenhirState056 ->
          _menhir_run_096 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _startpos _v _menhir_s _tok
      | MenhirState057 ->
          _menhir_run_096 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _startpos _v _menhir_s _tok
      | MenhirState065 ->
          _menhir_run_096 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _startpos _v _menhir_s _tok
      | MenhirState072 ->
          _menhir_run_096 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _startpos _v _menhir_s _tok
      | MenhirState122 ->
          _menhir_run_096 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _startpos _v _menhir_s _tok
      | MenhirState089 ->
          _menhir_run_096 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _startpos _v _menhir_s _tok
      | MenhirState111 ->
          _menhir_run_096 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _startpos _v _menhir_s _tok
      | MenhirState105 ->
          _menhir_run_096 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _startpos _v _menhir_s _tok
      | MenhirState100 ->
          _menhir_run_096 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _startpos _v _menhir_s _tok
      | MenhirState095 ->
          _menhir_run_096 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _startpos _v _menhir_s _tok
      | MenhirState077 ->
          _menhir_run_077 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _startpos _v _menhir_s _tok
      | MenhirState076 ->
          _menhir_run_077 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _startpos _v _menhir_s _tok
      | MenhirState073 ->
          _menhir_run_074 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _startpos _v _menhir_s _tok
      | MenhirState066 ->
          _menhir_run_067 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _startpos _v _menhir_s _tok
      | MenhirState058 ->
          _menhir_run_060 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _startpos _v _menhir_s _tok
      | _ ->
          _menhir_fail ()
  
  and _menhir_run_146 : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> _ -> _ -> (ttv_stack, _menhir_box_program) _menhir_state -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _startpos _v _menhir_s _tok ->
      match (_tok : MenhirBasics.token) with
      | SEMI ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          (match (_tok : MenhirBasics.token) with
          | IDENTIFIER _v_0 ->
              let _menhir_stack = MenhirCell1_term_variable (_menhir_stack, _menhir_s, _v, _startpos, _endpos) in
              _menhir_run_059 _menhir_stack _menhir_lexbuf _menhir_lexer _v_0 MenhirState147
          | RBRACE ->
              let x = _v in
              let _v = _menhir_action_34 x in
              _menhir_goto_nonempty_list_terminated_term_variable_SEMI__ _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s
          | _ ->
              _eRR ())
      | RBRACE ->
          let x = _v in
          let _v = _menhir_action_59 x in
          _menhir_goto_separated_nonempty_list_SEMI_term_variable_ _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s
      | _ ->
          _eRR ()
  
  and _menhir_goto_nonempty_list_terminated_term_variable_SEMI__ : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_program) _menhir_state -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s ->
      match _menhir_s with
      | MenhirState145 ->
          _menhir_run_153 _menhir_stack _menhir_lexbuf _menhir_lexer _v
      | MenhirState147 ->
          _menhir_run_149 _menhir_stack _menhir_lexbuf _menhir_lexer _v
      | _ ->
          _menhir_fail ()
  
  and _menhir_run_153 : type  ttv_stack. ((ttv_stack, _menhir_box_program) _menhir_cell1_data_constructor, _menhir_box_program) _menhir_cell1_list_formal_type_arguments_ -> _ -> _ -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v ->
      let xs = _v in
      let _v = _menhir_action_50 xs in
      _menhir_goto_semi_term_variable_ _menhir_stack _menhir_lexbuf _menhir_lexer _v
  
  and _menhir_goto_semi_term_variable_ : type  ttv_stack. ((ttv_stack, _menhir_box_program) _menhir_cell1_data_constructor, _menhir_box_program) _menhir_cell1_list_formal_type_arguments_ -> _ -> _ -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v ->
      let _endpos = _menhir_lexbuf.Lexing.lex_curr_p in
      let _tok = _menhir_lexer _menhir_lexbuf in
      let MenhirCell1_list_formal_type_arguments_ (_menhir_stack, _, xs) = _menhir_stack in
      let MenhirCell1_data_constructor (_menhir_stack, _menhir_s, d, _startpos_d_) = _menhir_stack in
      let (fields, _endpos__5_) = (_v, _endpos) in
      let _v = _menhir_action_42 _endpos__5_ _startpos_d_ d fields xs in
      let _menhir_stack = MenhirCell1_pattern (_menhir_stack, _menhir_s, _v) in
      match (_tok : MenhirBasics.token) with
      | ARROW ->
          let _menhir_s = MenhirState141 in
          let _tok = _menhir_lexer _menhir_lexbuf in
          (match (_tok : MenhirBasics.token) with
          | TAG _v ->
              _menhir_run_010 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s
          | MATCH ->
              _menhir_run_056 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
          | LPAR ->
              _menhir_run_057 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
          | LET ->
              _menhir_run_058 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
          | JUMP ->
              _menhir_run_066 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
          | JOIN ->
              _menhir_run_073 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
          | IDENTIFIER _v ->
              _menhir_run_059 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s
          | FUN ->
              _menhir_run_090 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
          | _ ->
              _eRR ())
      | _ ->
          _eRR ()
  
  and _menhir_run_056 : type  ttv_stack. ttv_stack -> _ -> _ -> (ttv_stack, _menhir_box_program) _menhir_state -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s ->
      let _startpos = _menhir_lexbuf.Lexing.lex_start_p in
      let _menhir_stack = MenhirCell1_MATCH (_menhir_stack, _menhir_s, _startpos) in
      let _menhir_s = MenhirState056 in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | TAG _v ->
          _menhir_run_010 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s
      | MATCH ->
          _menhir_run_056 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
      | LPAR ->
          _menhir_run_057 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
      | LET ->
          _menhir_run_058 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
      | JUMP ->
          _menhir_run_066 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
      | JOIN ->
          _menhir_run_073 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
      | IDENTIFIER _v ->
          _menhir_run_059 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s
      | FUN ->
          _menhir_run_090 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
      | _ ->
          _eRR ()
  
  and _menhir_run_057 : type  ttv_stack. ttv_stack -> _ -> _ -> (ttv_stack, _menhir_box_program) _menhir_state -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s ->
      let _startpos = _menhir_lexbuf.Lexing.lex_start_p in
      let _menhir_stack = MenhirCell1_LPAR (_menhir_stack, _menhir_s, _startpos) in
      let _menhir_s = MenhirState057 in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | TAG _v ->
          _menhir_run_010 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s
      | MATCH ->
          _menhir_run_056 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
      | LPAR ->
          _menhir_run_057 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
      | LET ->
          _menhir_run_058 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
      | JUMP ->
          _menhir_run_066 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
      | JOIN ->
          _menhir_run_073 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
      | IDENTIFIER _v ->
          _menhir_run_059 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s
      | FUN ->
          _menhir_run_090 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
      | _ ->
          _eRR ()
  
  and _menhir_run_058 : type  ttv_stack. ttv_stack -> _ -> _ -> (ttv_stack, _menhir_box_program) _menhir_state -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s ->
      let _startpos = _menhir_lexbuf.Lexing.lex_start_p in
      let _menhir_stack = MenhirCell1_LET (_menhir_stack, _menhir_s, _startpos) in
      let _menhir_s = MenhirState058 in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | IDENTIFIER _v ->
          _menhir_run_059 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s
      | _ ->
          _eRR ()
  
  and _menhir_run_066 : type  ttv_stack. ttv_stack -> _ -> _ -> (ttv_stack, _menhir_box_program) _menhir_state -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s ->
      let _startpos = _menhir_lexbuf.Lexing.lex_start_p in
      let _menhir_stack = MenhirCell1_JUMP (_menhir_stack, _menhir_s, _startpos) in
      let _menhir_s = MenhirState066 in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | IDENTIFIER _v ->
          _menhir_run_059 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s
      | _ ->
          _eRR ()
  
  and _menhir_run_073 : type  ttv_stack. ttv_stack -> _ -> _ -> (ttv_stack, _menhir_box_program) _menhir_state -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s ->
      let _startpos = _menhir_lexbuf.Lexing.lex_start_p in
      let _menhir_stack = MenhirCell1_JOIN (_menhir_stack, _menhir_s, _startpos) in
      let _menhir_s = MenhirState073 in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | IDENTIFIER _v ->
          _menhir_run_059 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s
      | _ ->
          _eRR ()
  
  and _menhir_run_090 : type  ttv_stack. ttv_stack -> _ -> _ -> (ttv_stack, _menhir_box_program) _menhir_state -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s ->
      let _startpos = _menhir_lexbuf.Lexing.lex_start_p in
      let _menhir_stack = MenhirCell1_FUN (_menhir_stack, _menhir_s, _startpos) in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | LBRACKET ->
          _menhir_run_061 _menhir_stack _menhir_lexbuf _menhir_lexer MenhirState090
      | COLON | EQ | LPAR ->
          let _v = _menhir_action_12 () in
          _menhir_run_092 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState090 _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_092 : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_program) _menhir_state -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      let _menhir_stack = MenhirCell1_list_formal_type_arguments_ (_menhir_stack, _menhir_s, _v) in
      match (_tok : MenhirBasics.token) with
      | LPAR ->
          _menhir_run_076 _menhir_stack _menhir_lexbuf _menhir_lexer MenhirState092
      | COLON | EQ ->
          let _v_0 = _menhir_action_16 () in
          _menhir_run_093 _menhir_stack _menhir_lexbuf _menhir_lexer _v_0 MenhirState092 _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_076 : type  ttv_stack. ttv_stack -> _ -> _ -> (ttv_stack, _menhir_box_program) _menhir_state -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s ->
      let _startpos = _menhir_lexbuf.Lexing.lex_start_p in
      let _menhir_stack = MenhirCell1_LPAR (_menhir_stack, _menhir_s, _startpos) in
      let _menhir_s = MenhirState076 in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | IDENTIFIER _v ->
          _menhir_run_059 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s
      | _ ->
          _eRR ()
  
  and _menhir_run_093 : type  ttv_stack. ((ttv_stack, _menhir_box_program) _menhir_cell1_list_formal_type_arguments_ as 'stack) -> _ -> _ -> _ -> ('stack, _menhir_box_program) _menhir_state -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      let _menhir_stack = MenhirCell1_list_term_arguments_ (_menhir_stack, _menhir_s, _v) in
      match (_tok : MenhirBasics.token) with
      | COLON ->
          _menhir_run_086 _menhir_stack _menhir_lexbuf _menhir_lexer MenhirState093
      | EQ ->
          let _v_0 = _menhir_action_40 () in
          _menhir_run_094 _menhir_stack _menhir_lexbuf _menhir_lexer _v_0 MenhirState093 _tok
      | _ ->
          _menhir_fail ()
  
  and _menhir_run_086 : type  ttv_stack. (((ttv_stack, _menhir_box_program) _menhir_cell1_list_formal_type_arguments_, _menhir_box_program) _menhir_cell1_list_term_arguments_ as 'stack) -> _ -> _ -> ('stack, _menhir_box_program) _menhir_state -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s ->
      let _menhir_stack = MenhirCell1_COLON (_menhir_stack, _menhir_s) in
      let _menhir_s = MenhirState086 in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | LPAR ->
          _menhir_run_020 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
      | IDENTIFIER _v ->
          _menhir_run_021 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s
      | FORALL ->
          _menhir_run_026 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
      | _ ->
          _eRR ()
  
  and _menhir_run_026 : type  ttv_stack. ttv_stack -> _ -> _ -> (ttv_stack, _menhir_box_program) _menhir_state -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s ->
      let _menhir_stack = MenhirCell1_FORALL (_menhir_stack, _menhir_s) in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | IDENTIFIER _v ->
          _menhir_run_004 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState026
      | DOT ->
          let _v = _menhir_action_20 () in
          _menhir_run_027 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState026 _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_027 : type  ttv_stack. ((ttv_stack, _menhir_box_program) _menhir_cell1_FORALL as 'stack) -> _ -> _ -> _ -> ('stack, _menhir_box_program) _menhir_state -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      let _menhir_stack = MenhirCell1_list_type_variable_ (_menhir_stack, _menhir_s, _v) in
      match (_tok : MenhirBasics.token) with
      | DOT ->
          let _menhir_s = MenhirState028 in
          let _tok = _menhir_lexer _menhir_lexbuf in
          (match (_tok : MenhirBasics.token) with
          | LPAR ->
              _menhir_run_020 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
          | IDENTIFIER _v ->
              _menhir_run_021 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s
          | FORALL ->
              _menhir_run_026 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
          | _ ->
              _eRR ())
      | _ ->
          _eRR ()
  
  and _menhir_run_094 : type  ttv_stack. (((ttv_stack, _menhir_box_program) _menhir_cell1_list_formal_type_arguments_, _menhir_box_program) _menhir_cell1_list_term_arguments_ as 'stack) -> _ -> _ -> _ -> ('stack, _menhir_box_program) _menhir_state -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      let _menhir_stack = MenhirCell1_option_preceded_COLON_typ__ (_menhir_stack, _menhir_s, _v) in
      match (_tok : MenhirBasics.token) with
      | EQ ->
          let _menhir_s = MenhirState095 in
          let _tok = _menhir_lexer _menhir_lexbuf in
          (match (_tok : MenhirBasics.token) with
          | TAG _v ->
              _menhir_run_010 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s
          | MATCH ->
              _menhir_run_056 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
          | LPAR ->
              _menhir_run_057 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
          | LET ->
              _menhir_run_058 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
          | JUMP ->
              _menhir_run_066 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
          | JOIN ->
              _menhir_run_073 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
          | IDENTIFIER _v ->
              _menhir_run_059 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s
          | FUN ->
              _menhir_run_090 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
          | _ ->
              _eRR ())
      | _ ->
          _eRR ()
  
  and _menhir_run_149 : type  ttv_stack. (ttv_stack, _menhir_box_program) _menhir_cell1_term_variable -> _ -> _ -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v ->
      let MenhirCell1_term_variable (_menhir_stack, _menhir_s, x, _, _) = _menhir_stack in
      let xs = _v in
      let _v = _menhir_action_35 x xs in
      _menhir_goto_nonempty_list_terminated_term_variable_SEMI__ _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s
  
  and _menhir_goto_separated_nonempty_list_SEMI_term_variable_ : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_program) _menhir_state -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s ->
      match _menhir_s with
      | MenhirState145 ->
          _menhir_run_150 _menhir_stack _menhir_lexbuf _menhir_lexer _v
      | MenhirState147 ->
          _menhir_run_148 _menhir_stack _menhir_lexbuf _menhir_lexer _v
      | _ ->
          _menhir_fail ()
  
  and _menhir_run_150 : type  ttv_stack. ((ttv_stack, _menhir_box_program) _menhir_cell1_data_constructor, _menhir_box_program) _menhir_cell1_list_formal_type_arguments_ -> _ -> _ -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v ->
      let xs = _v in
      let _v = _menhir_action_51 xs in
      _menhir_goto_semi_term_variable_ _menhir_stack _menhir_lexbuf _menhir_lexer _v
  
  and _menhir_run_148 : type  ttv_stack. (ttv_stack, _menhir_box_program) _menhir_cell1_term_variable -> _ -> _ -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v ->
      let MenhirCell1_term_variable (_menhir_stack, _menhir_s, x, _, _) = _menhir_stack in
      let xs = _v in
      let _v = _menhir_action_60 x xs in
      _menhir_goto_separated_nonempty_list_SEMI_term_variable_ _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s
  
  and _menhir_run_096 : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> _ -> _ -> (ttv_stack, _menhir_box_program) _menhir_state -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _startpos _v _menhir_s _tok ->
      let (_endpos_x_, _startpos_x_, x) = (_endpos, _startpos, _v) in
      let _v = _menhir_action_69 x in
      _menhir_goto_term0 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos_x_ _startpos_x_ _v _menhir_s _tok
  
  and _menhir_goto_term0 : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> _ -> _ -> (ttv_stack, _menhir_box_program) _menhir_state -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _startpos _v _menhir_s _tok ->
      match _menhir_s with
      | MenhirState100 ->
          _menhir_run_101 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _startpos _v _tok
      | MenhirState055 ->
          _menhir_run_098 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _startpos _v _menhir_s _tok
      | MenhirState141 ->
          _menhir_run_098 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _startpos _v _menhir_s _tok
      | MenhirState056 ->
          _menhir_run_098 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _startpos _v _menhir_s _tok
      | MenhirState057 ->
          _menhir_run_098 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _startpos _v _menhir_s _tok
      | MenhirState065 ->
          _menhir_run_098 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _startpos _v _menhir_s _tok
      | MenhirState072 ->
          _menhir_run_098 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _startpos _v _menhir_s _tok
      | MenhirState122 ->
          _menhir_run_098 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _startpos _v _menhir_s _tok
      | MenhirState089 ->
          _menhir_run_098 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _startpos _v _menhir_s _tok
      | MenhirState111 ->
          _menhir_run_098 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _startpos _v _menhir_s _tok
      | MenhirState105 ->
          _menhir_run_098 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _startpos _v _menhir_s _tok
      | MenhirState095 ->
          _menhir_run_098 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _startpos _v _menhir_s _tok
      | _ ->
          _menhir_fail ()
  
  and _menhir_run_101 : type  ttv_stack. (ttv_stack, _menhir_box_program) _menhir_cell1_loc_term1_ -> _ -> _ -> _ -> _ -> _ -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _startpos _v _tok ->
      let (_endpos_t_, _startpos_t_, t) = (_endpos, _startpos, _v) in
      let _v = _menhir_action_23 _endpos_t_ _startpos_t_ t in
      let _endpos = _endpos_t_ in
      let MenhirCell1_loc_term1_ (_menhir_stack, _menhir_s, t1, _startpos_t1_) = _menhir_stack in
      let (_endpos_t2_, t2) = (_endpos, _v) in
      let _v = _menhir_action_76 t1 t2 in
      _menhir_goto_term1 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos_t2_ _startpos_t1_ _v _menhir_s _tok
  
  and _menhir_goto_term1 : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> _ -> _ -> (ttv_stack, _menhir_box_program) _menhir_state -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _startpos _v _menhir_s _tok ->
      match (_tok : MenhirBasics.token) with
      | IDENTIFIER _ | JUMP | LBRACKET | LPAR | MATCH | TAG _ ->
          let (_endpos_t_, _startpos_t_, t) = (_endpos, _startpos, _v) in
          let _v = _menhir_action_24 _endpos_t_ _startpos_t_ t in
          let _startpos = _startpos_t_ in
          let _menhir_stack = MenhirCell1_loc_term1_ (_menhir_stack, _menhir_s, _v, _startpos) in
          (match (_tok : MenhirBasics.token) with
          | TAG _v_0 ->
              _menhir_run_010 _menhir_stack _menhir_lexbuf _menhir_lexer _v_0 MenhirState100
          | MATCH ->
              _menhir_run_056 _menhir_stack _menhir_lexbuf _menhir_lexer MenhirState100
          | LPAR ->
              _menhir_run_057 _menhir_stack _menhir_lexbuf _menhir_lexer MenhirState100
          | LBRACKET ->
              _menhir_run_068 _menhir_stack _menhir_lexbuf _menhir_lexer MenhirState100
          | JUMP ->
              _menhir_run_066 _menhir_stack _menhir_lexbuf _menhir_lexer MenhirState100
          | IDENTIFIER _v_1 ->
              _menhir_run_059 _menhir_stack _menhir_lexbuf _menhir_lexer _v_1 MenhirState100
          | _ ->
              _menhir_fail ())
      | BAR | COLON | END | EOF | IN | RBRACE | RETURN | RPAR | SEMI ->
          let (_endpos_t_, _startpos_t_, t) = (_endpos, _startpos, _v) in
          let _v = _menhir_action_65 t in
          _menhir_goto_term _menhir_stack _menhir_lexbuf _menhir_lexer _endpos_t_ _startpos_t_ _v _menhir_s _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_068 : type  ttv_stack. ttv_stack -> _ -> _ -> (ttv_stack, _menhir_box_program) _menhir_state -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s ->
      let _menhir_stack = MenhirCell1_LBRACKET (_menhir_stack, _menhir_s) in
      let _menhir_s = MenhirState068 in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | LPAR ->
          _menhir_run_020 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
      | IDENTIFIER _v ->
          _menhir_run_021 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s
      | FORALL ->
          _menhir_run_026 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
      | _ ->
          _eRR ()
  
  and _menhir_goto_term : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> _ -> _ -> (ttv_stack, _menhir_box_program) _menhir_state -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _startpos _v _menhir_s _tok ->
      match _menhir_s with
      | MenhirState057 ->
          _menhir_run_129 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _startpos _v _menhir_s _tok
      | MenhirState055 ->
          _menhir_run_099 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _startpos _v _menhir_s _tok
      | MenhirState141 ->
          _menhir_run_099 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _startpos _v _menhir_s _tok
      | MenhirState056 ->
          _menhir_run_099 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _startpos _v _menhir_s _tok
      | MenhirState065 ->
          _menhir_run_099 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _startpos _v _menhir_s _tok
      | MenhirState072 ->
          _menhir_run_099 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _startpos _v _menhir_s _tok
      | MenhirState122 ->
          _menhir_run_099 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _startpos _v _menhir_s _tok
      | MenhirState089 ->
          _menhir_run_099 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _startpos _v _menhir_s _tok
      | MenhirState111 ->
          _menhir_run_099 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _startpos _v _menhir_s _tok
      | MenhirState105 ->
          _menhir_run_099 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _startpos _v _menhir_s _tok
      | MenhirState095 ->
          _menhir_run_099 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _startpos _v _menhir_s _tok
      | _ ->
          _menhir_fail ()
  
  and _menhir_run_129 : type  ttv_stack. ((ttv_stack, _menhir_box_program) _menhir_cell1_LPAR as 'stack) -> _ -> _ -> _ -> _ -> _ -> ('stack, _menhir_box_program) _menhir_state -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _startpos _v _menhir_s _tok ->
      match (_tok : MenhirBasics.token) with
      | RPAR ->
          let _endpos_0 = _menhir_lexbuf.Lexing.lex_curr_p in
          let _tok = _menhir_lexer _menhir_lexbuf in
          let MenhirCell1_LPAR (_menhir_stack, _menhir_s, _startpos__1_) = _menhir_stack in
          let (_endpos__3_, t) = (_endpos_0, _v) in
          let _v = _menhir_action_72 t in
          _menhir_goto_term0 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos__3_ _startpos__1_ _v _menhir_s _tok
      | COLON ->
          let (_endpos_t_, _startpos_t_, t) = (_endpos, _startpos, _v) in
          let _v = _menhir_action_22 _endpos_t_ _startpos_t_ t in
          _menhir_goto_loc_term_ _menhir_stack _menhir_lexbuf _menhir_lexer _endpos_t_ _v _menhir_s _tok
      | _ ->
          _eRR ()
  
  and _menhir_goto_loc_term_ : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> _ -> (ttv_stack, _menhir_box_program) _menhir_state -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _v _menhir_s _tok ->
      match _menhir_s with
      | MenhirState055 ->
          _menhir_run_163 _menhir_stack _v _tok
      | MenhirState141 ->
          _menhir_run_142 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState056 ->
          _menhir_run_135 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _v _menhir_s _tok
      | MenhirState057 ->
          _menhir_run_131 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _v _menhir_s _tok
      | MenhirState065 ->
          _menhir_run_128 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _v _tok
      | MenhirState122 ->
          _menhir_run_123 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _v _tok
      | MenhirState089 ->
          _menhir_run_121 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _v _menhir_s _tok
      | MenhirState095 ->
          _menhir_run_117 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _v _tok
      | MenhirState072 ->
          _menhir_run_110 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _v _menhir_s _tok
      | MenhirState111 ->
          _menhir_run_110 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _v _menhir_s _tok
      | MenhirState105 ->
          _menhir_run_110 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _v _menhir_s _tok
      | _ ->
          _menhir_fail ()
  
  and _menhir_run_142 : type  ttv_stack. (ttv_stack, _menhir_box_program) _menhir_cell1_pattern -> _ -> _ -> _ -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let MenhirCell1_pattern (_menhir_stack, _menhir_s, p) = _menhir_stack in
      let t = _v in
      let _v = _menhir_action_05 p t in
      _menhir_goto_clause _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
  
  and _menhir_goto_clause : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_program) _menhir_state -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      match _menhir_s with
      | MenhirState159 ->
          _menhir_run_158 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState138 ->
          _menhir_run_158 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState139 ->
          _menhir_run_154 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | _ ->
          _menhir_fail ()
  
  and _menhir_run_158 : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_program) _menhir_state -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      match (_tok : MenhirBasics.token) with
      | BAR ->
          let _menhir_stack = MenhirCell1_clause (_menhir_stack, _menhir_s, _v) in
          let _menhir_s = MenhirState159 in
          let _tok = _menhir_lexer _menhir_lexbuf in
          (match (_tok : MenhirBasics.token) with
          | TAG _v ->
              _menhir_run_010 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s
          | _ ->
              _eRR ())
      | END ->
          let x = _v in
          let _v = _menhir_action_55 x in
          _menhir_goto_separated_nonempty_list_BAR_clause_ _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s
      | _ ->
          _eRR ()
  
  and _menhir_goto_separated_nonempty_list_BAR_clause_ : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_program) _menhir_state -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s ->
      match _menhir_s with
      | MenhirState159 ->
          _menhir_run_160 _menhir_stack _menhir_lexbuf _menhir_lexer _v
      | MenhirState138 ->
          _menhir_run_156 _menhir_stack _menhir_lexbuf _menhir_lexer _v
      | _ ->
          _menhir_fail ()
  
  and _menhir_run_160 : type  ttv_stack. (ttv_stack, _menhir_box_program) _menhir_cell1_clause -> _ -> _ -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v ->
      let MenhirCell1_clause (_menhir_stack, _menhir_s, x) = _menhir_stack in
      let xs = _v in
      let _v = _menhir_action_56 x xs in
      _menhir_goto_separated_nonempty_list_BAR_clause_ _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s
  
  and _menhir_run_156 : type  ttv_stack. (((ttv_stack, _menhir_box_program) _menhir_cell1_MATCH, _menhir_box_program) _menhir_cell1_loc_term_, _menhir_box_program) _menhir_cell1_typ -> _ -> _ -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v ->
      let xs = _v in
      let _v = _menhir_action_04 xs in
      _menhir_goto_bar_clause_ _menhir_stack _menhir_lexbuf _menhir_lexer _v
  
  and _menhir_goto_bar_clause_ : type  ttv_stack. (((ttv_stack, _menhir_box_program) _menhir_cell1_MATCH, _menhir_box_program) _menhir_cell1_loc_term_, _menhir_box_program) _menhir_cell1_typ -> _ -> _ -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v ->
      let _endpos = _menhir_lexbuf.Lexing.lex_curr_p in
      let _tok = _menhir_lexer _menhir_lexbuf in
      let MenhirCell1_typ (_menhir_stack, _, ty, _) = _menhir_stack in
      let MenhirCell1_loc_term_ (_menhir_stack, _, t, _) = _menhir_stack in
      let MenhirCell1_MATCH (_menhir_stack, _menhir_s, _startpos__1_) = _menhir_stack in
      let (_endpos__7_, cs) = (_endpos, _v) in
      let _v = _menhir_action_74 cs t ty in
      _menhir_goto_term0 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos__7_ _startpos__1_ _v _menhir_s _tok
  
  and _menhir_run_154 : type  ttv_stack. ((ttv_stack, _menhir_box_program) _menhir_cell1_BAR as 'stack) -> _ -> _ -> _ -> ('stack, _menhir_box_program) _menhir_state -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      match (_tok : MenhirBasics.token) with
      | BAR ->
          let _menhir_stack = MenhirCell1_clause (_menhir_stack, _menhir_s, _v) in
          _menhir_run_139 _menhir_stack _menhir_lexbuf _menhir_lexer MenhirState154
      | END ->
          let MenhirCell1_BAR (_menhir_stack, _menhir_s) = _menhir_stack in
          let x = _v in
          let _v = _menhir_action_28 x in
          _menhir_goto_nonempty_list_preceded_BAR_clause__ _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s
      | _ ->
          _eRR ()
  
  and _menhir_run_139 : type  ttv_stack. ttv_stack -> _ -> _ -> (ttv_stack, _menhir_box_program) _menhir_state -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s ->
      let _menhir_stack = MenhirCell1_BAR (_menhir_stack, _menhir_s) in
      let _menhir_s = MenhirState139 in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | TAG _v ->
          _menhir_run_010 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s
      | _ ->
          _eRR ()
  
  and _menhir_goto_nonempty_list_preceded_BAR_clause__ : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_program) _menhir_state -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s ->
      match _menhir_s with
      | MenhirState138 ->
          _menhir_run_157 _menhir_stack _menhir_lexbuf _menhir_lexer _v
      | MenhirState154 ->
          _menhir_run_155 _menhir_stack _menhir_lexbuf _menhir_lexer _v
      | _ ->
          _menhir_fail ()
  
  and _menhir_run_157 : type  ttv_stack. (((ttv_stack, _menhir_box_program) _menhir_cell1_MATCH, _menhir_box_program) _menhir_cell1_loc_term_, _menhir_box_program) _menhir_cell1_typ -> _ -> _ -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v ->
      let xs = _v in
      let _v = _menhir_action_03 xs in
      _menhir_goto_bar_clause_ _menhir_stack _menhir_lexbuf _menhir_lexer _v
  
  and _menhir_run_155 : type  ttv_stack. ((ttv_stack, _menhir_box_program) _menhir_cell1_BAR, _menhir_box_program) _menhir_cell1_clause -> _ -> _ -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v ->
      let MenhirCell1_clause (_menhir_stack, _, x) = _menhir_stack in
      let MenhirCell1_BAR (_menhir_stack, _menhir_s) = _menhir_stack in
      let xs = _v in
      let _v = _menhir_action_29 x xs in
      _menhir_goto_nonempty_list_preceded_BAR_clause__ _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s
  
  and _menhir_run_135 : type  ttv_stack. ((ttv_stack, _menhir_box_program) _menhir_cell1_MATCH as 'stack) -> _ -> _ -> _ -> _ -> ('stack, _menhir_box_program) _menhir_state -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _v _menhir_s _tok ->
      let _menhir_stack = MenhirCell1_loc_term_ (_menhir_stack, _menhir_s, _v, _endpos) in
      match (_tok : MenhirBasics.token) with
      | RETURN ->
          let _menhir_s = MenhirState136 in
          let _tok = _menhir_lexer _menhir_lexbuf in
          (match (_tok : MenhirBasics.token) with
          | LPAR ->
              _menhir_run_020 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
          | IDENTIFIER _v ->
              _menhir_run_021 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s
          | FORALL ->
              _menhir_run_026 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
          | _ ->
              _eRR ())
      | _ ->
          _eRR ()
  
  and _menhir_run_131 : type  ttv_stack. ((ttv_stack, _menhir_box_program) _menhir_cell1_LPAR as 'stack) -> _ -> _ -> _ -> _ -> ('stack, _menhir_box_program) _menhir_state -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _v _menhir_s _tok ->
      let _menhir_stack = MenhirCell1_loc_term_ (_menhir_stack, _menhir_s, _v, _endpos) in
      match (_tok : MenhirBasics.token) with
      | COLON ->
          let _menhir_s = MenhirState132 in
          let _tok = _menhir_lexer _menhir_lexbuf in
          (match (_tok : MenhirBasics.token) with
          | LPAR ->
              _menhir_run_020 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
          | IDENTIFIER _v ->
              _menhir_run_021 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s
          | FORALL ->
              _menhir_run_026 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
          | _ ->
              _eRR ())
      | _ ->
          _eRR ()
  
  and _menhir_run_128 : type  ttv_stack. (((ttv_stack, _menhir_box_program) _menhir_cell1_LET, _menhir_box_program) _menhir_cell1_term_variable, _menhir_box_program) _menhir_cell1_non_recursive_def -> _ -> _ -> _ -> _ -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _v _tok ->
      let MenhirCell1_non_recursive_def (_menhir_stack, _, def, _) = _menhir_stack in
      let MenhirCell1_term_variable (_menhir_stack, _, f, _, _) = _menhir_stack in
      let MenhirCell1_LET (_menhir_stack, _menhir_s, _startpos__1_) = _menhir_stack in
      let (_endpos_t_, t) = (_endpos, _v) in
      let _v = _menhir_action_68 def f t in
      _menhir_goto_term _menhir_stack _menhir_lexbuf _menhir_lexer _endpos_t_ _startpos__1_ _v _menhir_s _tok
  
  and _menhir_run_123 : type  ttv_stack. ((((((ttv_stack, _menhir_box_program) _menhir_cell1_JOIN, _menhir_box_program) _menhir_cell1_term_variable, _menhir_box_program) _menhir_cell1_list_formal_type_arguments_, _menhir_box_program) _menhir_cell1_list_term_arguments_, _menhir_box_program) _menhir_cell1_option_preceded_COLON_typ__, _menhir_box_program) _menhir_cell1_loc_term_ -> _ -> _ -> _ -> _ -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _v _tok ->
      let MenhirCell1_loc_term_ (_menhir_stack, _, t1, _) = _menhir_stack in
      let MenhirCell1_option_preceded_COLON_typ__ (_menhir_stack, _, codomain) = _menhir_stack in
      let MenhirCell1_list_term_arguments_ (_menhir_stack, _, xs_inlined1) = _menhir_stack in
      let MenhirCell1_list_formal_type_arguments_ (_menhir_stack, _, xs) = _menhir_stack in
      let MenhirCell1_term_variable (_menhir_stack, _, j, _, _) = _menhir_stack in
      let MenhirCell1_JOIN (_menhir_stack, _menhir_s, _startpos__1_) = _menhir_stack in
      let (_endpos_t2_, t2) = (_endpos, _v) in
      let _v = _menhir_action_67 codomain j t1 t2 xs xs_inlined1 in
      _menhir_goto_term _menhir_stack _menhir_lexbuf _menhir_lexer _endpos_t2_ _startpos__1_ _v _menhir_s _tok
  
  and _menhir_run_121 : type  ttv_stack. ((((((ttv_stack, _menhir_box_program) _menhir_cell1_JOIN, _menhir_box_program) _menhir_cell1_term_variable, _menhir_box_program) _menhir_cell1_list_formal_type_arguments_, _menhir_box_program) _menhir_cell1_list_term_arguments_, _menhir_box_program) _menhir_cell1_option_preceded_COLON_typ__ as 'stack) -> _ -> _ -> _ -> _ -> ('stack, _menhir_box_program) _menhir_state -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _v _menhir_s _tok ->
      let _menhir_stack = MenhirCell1_loc_term_ (_menhir_stack, _menhir_s, _v, _endpos) in
      match (_tok : MenhirBasics.token) with
      | IN ->
          let _menhir_s = MenhirState122 in
          let _tok = _menhir_lexer _menhir_lexbuf in
          (match (_tok : MenhirBasics.token) with
          | TAG _v ->
              _menhir_run_010 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s
          | MATCH ->
              _menhir_run_056 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
          | LPAR ->
              _menhir_run_057 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
          | LET ->
              _menhir_run_058 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
          | JUMP ->
              _menhir_run_066 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
          | JOIN ->
              _menhir_run_073 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
          | IDENTIFIER _v ->
              _menhir_run_059 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s
          | FUN ->
              _menhir_run_090 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
          | _ ->
              _eRR ())
      | _ ->
          _eRR ()
  
  and _menhir_run_117 : type  ttv_stack. (((ttv_stack, _menhir_box_program) _menhir_cell1_list_formal_type_arguments_, _menhir_box_program) _menhir_cell1_list_term_arguments_, _menhir_box_program) _menhir_cell1_option_preceded_COLON_typ__ -> _ -> _ -> _ -> _ -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _v _tok ->
      let MenhirCell1_option_preceded_COLON_typ__ (_menhir_stack, _, codomain) = _menhir_stack in
      let MenhirCell1_list_term_arguments_ (_menhir_stack, _, xs_inlined1) = _menhir_stack in
      let MenhirCell1_list_formal_type_arguments_ (_menhir_stack, _menhir_s, xs) = _menhir_stack in
      let (_endpos_t_, t) = (_endpos, _v) in
      let _v = _menhir_action_27 codomain t xs xs_inlined1 in
      _menhir_goto_non_recursive_def _menhir_stack _menhir_lexbuf _menhir_lexer _endpos_t_ _v _menhir_s _tok
  
  and _menhir_goto_non_recursive_def : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> _ -> (ttv_stack, _menhir_box_program) _menhir_state -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _v _menhir_s _tok ->
      match _menhir_s with
      | MenhirState090 ->
          _menhir_run_091 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _v _tok
      | MenhirState060 ->
          _menhir_run_064 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _v _menhir_s _tok
      | _ ->
          _menhir_fail ()
  
  and _menhir_run_091 : type  ttv_stack. (ttv_stack, _menhir_box_program) _menhir_cell1_FUN -> _ -> _ -> _ -> _ -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _v _tok ->
      let (_endpos_def_, def) = (_endpos, _v) in
      let _v = _menhir_action_08 def in
      let _endpos = _endpos_def_ in
      let MenhirCell1_FUN (_menhir_stack, _menhir_s, _startpos__1_) = _menhir_stack in
      let (_endpos_def_, def) = (_endpos, _v) in
      let _v = _menhir_action_66 def in
      _menhir_goto_term _menhir_stack _menhir_lexbuf _menhir_lexer _endpos_def_ _startpos__1_ _v _menhir_s _tok
  
  and _menhir_run_064 : type  ttv_stack. (((ttv_stack, _menhir_box_program) _menhir_cell1_LET, _menhir_box_program) _menhir_cell1_term_variable as 'stack) -> _ -> _ -> _ -> _ -> ('stack, _menhir_box_program) _menhir_state -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _v _menhir_s _tok ->
      let _menhir_stack = MenhirCell1_non_recursive_def (_menhir_stack, _menhir_s, _v, _endpos) in
      match (_tok : MenhirBasics.token) with
      | IN ->
          let _menhir_s = MenhirState065 in
          let _tok = _menhir_lexer _menhir_lexbuf in
          (match (_tok : MenhirBasics.token) with
          | TAG _v ->
              _menhir_run_010 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s
          | MATCH ->
              _menhir_run_056 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
          | LPAR ->
              _menhir_run_057 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
          | LET ->
              _menhir_run_058 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
          | JUMP ->
              _menhir_run_066 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
          | JOIN ->
              _menhir_run_073 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
          | IDENTIFIER _v ->
              _menhir_run_059 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s
          | FUN ->
              _menhir_run_090 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
          | _ ->
              _eRR ())
      | _ ->
          _eRR ()
  
  and _menhir_run_110 : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> _ -> (ttv_stack, _menhir_box_program) _menhir_state -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _v _menhir_s _tok ->
      match (_tok : MenhirBasics.token) with
      | SEMI ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          (match (_tok : MenhirBasics.token) with
          | TAG _v_0 ->
              let _menhir_stack = MenhirCell1_loc_term_ (_menhir_stack, _menhir_s, _v, _endpos) in
              _menhir_run_010 _menhir_stack _menhir_lexbuf _menhir_lexer _v_0 MenhirState111
          | MATCH ->
              let _menhir_stack = MenhirCell1_loc_term_ (_menhir_stack, _menhir_s, _v, _endpos) in
              _menhir_run_056 _menhir_stack _menhir_lexbuf _menhir_lexer MenhirState111
          | LPAR ->
              let _menhir_stack = MenhirCell1_loc_term_ (_menhir_stack, _menhir_s, _v, _endpos) in
              _menhir_run_057 _menhir_stack _menhir_lexbuf _menhir_lexer MenhirState111
          | LET ->
              let _menhir_stack = MenhirCell1_loc_term_ (_menhir_stack, _menhir_s, _v, _endpos) in
              _menhir_run_058 _menhir_stack _menhir_lexbuf _menhir_lexer MenhirState111
          | JUMP ->
              let _menhir_stack = MenhirCell1_loc_term_ (_menhir_stack, _menhir_s, _v, _endpos) in
              _menhir_run_066 _menhir_stack _menhir_lexbuf _menhir_lexer MenhirState111
          | JOIN ->
              let _menhir_stack = MenhirCell1_loc_term_ (_menhir_stack, _menhir_s, _v, _endpos) in
              _menhir_run_073 _menhir_stack _menhir_lexbuf _menhir_lexer MenhirState111
          | IDENTIFIER _v_1 ->
              let _menhir_stack = MenhirCell1_loc_term_ (_menhir_stack, _menhir_s, _v, _endpos) in
              _menhir_run_059 _menhir_stack _menhir_lexbuf _menhir_lexer _v_1 MenhirState111
          | FUN ->
              let _menhir_stack = MenhirCell1_loc_term_ (_menhir_stack, _menhir_s, _v, _endpos) in
              _menhir_run_090 _menhir_stack _menhir_lexbuf _menhir_lexer MenhirState111
          | RBRACE ->
              let x = _v in
              let _v = _menhir_action_32 x in
              _menhir_goto_nonempty_list_terminated_loc_term__SEMI__ _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s
          | _ ->
              _eRR ())
      | RBRACE ->
          let x = _v in
          let _v = _menhir_action_57 x in
          _menhir_goto_separated_nonempty_list_SEMI_loc_term__ _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s
      | _ ->
          _eRR ()
  
  and _menhir_goto_nonempty_list_terminated_loc_term__SEMI__ : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_program) _menhir_state -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s ->
      match _menhir_s with
      | MenhirState111 ->
          _menhir_run_113 _menhir_stack _menhir_lexbuf _menhir_lexer _v
      | MenhirState072 ->
          _menhir_run_109 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s
      | MenhirState105 ->
          _menhir_run_109 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s
      | _ ->
          _menhir_fail ()
  
  and _menhir_run_113 : type  ttv_stack. (ttv_stack, _menhir_box_program) _menhir_cell1_loc_term_ -> _ -> _ -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v ->
      let MenhirCell1_loc_term_ (_menhir_stack, _menhir_s, x, _) = _menhir_stack in
      let xs = _v in
      let _v = _menhir_action_33 x xs in
      _menhir_goto_nonempty_list_terminated_loc_term__SEMI__ _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s
  
  and _menhir_run_109 : type  ttv_stack. ((ttv_stack, _menhir_box_program) _menhir_cell1_list_actual_type_arguments_ as 'stack) -> _ -> _ -> _ -> ('stack, _menhir_box_program) _menhir_state -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s ->
      let xs = _v in
      let _v = _menhir_action_47 xs in
      _menhir_goto_semi_loc_term__ _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s
  
  and _menhir_goto_semi_loc_term__ : type  ttv_stack. ((ttv_stack, _menhir_box_program) _menhir_cell1_list_actual_type_arguments_ as 'stack) -> _ -> _ -> _ -> ('stack, _menhir_box_program) _menhir_state -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s ->
      match _menhir_s with
      | MenhirState072 ->
          _menhir_run_124 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s
      | MenhirState105 ->
          _menhir_run_107 _menhir_stack _menhir_lexbuf _menhir_lexer _v
      | _ ->
          _menhir_fail ()
  
  and _menhir_run_124 : type  ttv_stack. ((((ttv_stack, _menhir_box_program) _menhir_cell1_JUMP, _menhir_box_program) _menhir_cell1_term_variable, _menhir_box_program) _menhir_cell1_list_actual_type_arguments_ as 'stack) -> _ -> _ -> _ -> ('stack, _menhir_box_program) _menhir_state -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s ->
      let _menhir_stack = MenhirCell1_semi_loc_term__ (_menhir_stack, _menhir_s, _v) in
      let _endpos = _menhir_lexbuf.Lexing.lex_curr_p in
      let _menhir_stack = MenhirCell0_RBRACE (_menhir_stack, _endpos) in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | COLON ->
          let _menhir_s = MenhirState126 in
          let _tok = _menhir_lexer _menhir_lexbuf in
          (match (_tok : MenhirBasics.token) with
          | LPAR ->
              _menhir_run_020 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
          | IDENTIFIER _v ->
              _menhir_run_021 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s
          | FORALL ->
              _menhir_run_026 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
          | _ ->
              _eRR ())
      | _ ->
          _eRR ()
  
  and _menhir_run_107 : type  ttv_stack. ((ttv_stack, _menhir_box_program) _menhir_cell1_data_constructor, _menhir_box_program) _menhir_cell1_list_actual_type_arguments_ -> _ -> _ -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v ->
      let _endpos = _menhir_lexbuf.Lexing.lex_curr_p in
      let _tok = _menhir_lexer _menhir_lexbuf in
      let MenhirCell1_list_actual_type_arguments_ (_menhir_stack, _, xs) = _menhir_stack in
      let MenhirCell1_data_constructor (_menhir_stack, _menhir_s, d, _startpos_d_) = _menhir_stack in
      let (fields, _endpos__5_) = (_v, _endpos) in
      let _v = _menhir_action_70 d fields xs in
      _menhir_goto_term0 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos__5_ _startpos_d_ _v _menhir_s _tok
  
  and _menhir_goto_separated_nonempty_list_SEMI_loc_term__ : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_program) _menhir_state -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s ->
      match _menhir_s with
      | MenhirState111 ->
          _menhir_run_112 _menhir_stack _menhir_lexbuf _menhir_lexer _v
      | MenhirState072 ->
          _menhir_run_106 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s
      | MenhirState105 ->
          _menhir_run_106 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s
      | _ ->
          _menhir_fail ()
  
  and _menhir_run_112 : type  ttv_stack. (ttv_stack, _menhir_box_program) _menhir_cell1_loc_term_ -> _ -> _ -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v ->
      let MenhirCell1_loc_term_ (_menhir_stack, _menhir_s, x, _) = _menhir_stack in
      let xs = _v in
      let _v = _menhir_action_58 x xs in
      _menhir_goto_separated_nonempty_list_SEMI_loc_term__ _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s
  
  and _menhir_run_106 : type  ttv_stack. ((ttv_stack, _menhir_box_program) _menhir_cell1_list_actual_type_arguments_ as 'stack) -> _ -> _ -> _ -> ('stack, _menhir_box_program) _menhir_state -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s ->
      let xs = _v in
      let _v = _menhir_action_48 xs in
      _menhir_goto_semi_loc_term__ _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s
  
  and _menhir_run_099 : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> _ -> _ -> (ttv_stack, _menhir_box_program) _menhir_state -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _startpos _v _menhir_s _tok ->
      let (_endpos_t_, _startpos_t_, t) = (_endpos, _startpos, _v) in
      let _v = _menhir_action_22 _endpos_t_ _startpos_t_ t in
      _menhir_goto_loc_term_ _menhir_stack _menhir_lexbuf _menhir_lexer _endpos_t_ _v _menhir_s _tok
  
  and _menhir_run_098 : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> _ -> _ -> (ttv_stack, _menhir_box_program) _menhir_state -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _startpos _v _menhir_s _tok ->
      let (_endpos_t_, _startpos_t_, t) = (_endpos, _startpos, _v) in
      let _v = _menhir_action_75 t in
      _menhir_goto_term1 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos_t_ _startpos_t_ _v _menhir_s _tok
  
  and _menhir_run_077 : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> _ -> _ -> (ttv_stack, _menhir_box_program) _menhir_state -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _startpos _v _menhir_s _tok ->
      match (_tok : MenhirBasics.token) with
      | IDENTIFIER _v_0 ->
          let _menhir_stack = MenhirCell1_term_variable (_menhir_stack, _menhir_s, _v, _startpos, _endpos) in
          _menhir_run_059 _menhir_stack _menhir_lexbuf _menhir_lexer _v_0 MenhirState077
      | COLON ->
          let x = _v in
          let _v = _menhir_action_30 x in
          _menhir_goto_nonempty_list_term_variable_ _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s
      | _ ->
          _eRR ()
  
  and _menhir_goto_nonempty_list_term_variable_ : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_program) _menhir_state -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s ->
      match _menhir_s with
      | MenhirState076 ->
          _menhir_run_079 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s
      | MenhirState077 ->
          _menhir_run_078 _menhir_stack _menhir_lexbuf _menhir_lexer _v
      | _ ->
          _menhir_fail ()
  
  and _menhir_run_079 : type  ttv_stack. ((ttv_stack, _menhir_box_program) _menhir_cell1_LPAR as 'stack) -> _ -> _ -> _ -> ('stack, _menhir_box_program) _menhir_state -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s ->
      let _menhir_stack = MenhirCell1_nonempty_list_term_variable_ (_menhir_stack, _menhir_s, _v) in
      let _menhir_s = MenhirState080 in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | LPAR ->
          _menhir_run_020 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
      | IDENTIFIER _v ->
          _menhir_run_021 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s
      | FORALL ->
          _menhir_run_026 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
      | _ ->
          _eRR ()
  
  and _menhir_run_078 : type  ttv_stack. (ttv_stack, _menhir_box_program) _menhir_cell1_term_variable -> _ -> _ -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v ->
      let MenhirCell1_term_variable (_menhir_stack, _menhir_s, x, _, _) = _menhir_stack in
      let xs = _v in
      let _v = _menhir_action_31 x xs in
      _menhir_goto_nonempty_list_term_variable_ _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s
  
  and _menhir_run_074 : type  ttv_stack. ((ttv_stack, _menhir_box_program) _menhir_cell1_JOIN as 'stack) -> _ -> _ -> _ -> _ -> _ -> ('stack, _menhir_box_program) _menhir_state -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _startpos _v _menhir_s _tok ->
      let _menhir_stack = MenhirCell1_term_variable (_menhir_stack, _menhir_s, _v, _startpos, _endpos) in
      match (_tok : MenhirBasics.token) with
      | LBRACKET ->
          _menhir_run_061 _menhir_stack _menhir_lexbuf _menhir_lexer MenhirState074
      | COLON | EQ | LPAR ->
          let _v_0 = _menhir_action_12 () in
          _menhir_run_075 _menhir_stack _menhir_lexbuf _menhir_lexer _v_0 MenhirState074 _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_075 : type  ttv_stack. (((ttv_stack, _menhir_box_program) _menhir_cell1_JOIN, _menhir_box_program) _menhir_cell1_term_variable as 'stack) -> _ -> _ -> _ -> ('stack, _menhir_box_program) _menhir_state -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      let _menhir_stack = MenhirCell1_list_formal_type_arguments_ (_menhir_stack, _menhir_s, _v) in
      match (_tok : MenhirBasics.token) with
      | LPAR ->
          _menhir_run_076 _menhir_stack _menhir_lexbuf _menhir_lexer MenhirState075
      | COLON | EQ ->
          let _v_0 = _menhir_action_16 () in
          _menhir_run_085 _menhir_stack _menhir_lexbuf _menhir_lexer _v_0 MenhirState075 _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_085 : type  ttv_stack. ((((ttv_stack, _menhir_box_program) _menhir_cell1_JOIN, _menhir_box_program) _menhir_cell1_term_variable, _menhir_box_program) _menhir_cell1_list_formal_type_arguments_ as 'stack) -> _ -> _ -> _ -> ('stack, _menhir_box_program) _menhir_state -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      let _menhir_stack = MenhirCell1_list_term_arguments_ (_menhir_stack, _menhir_s, _v) in
      match (_tok : MenhirBasics.token) with
      | COLON ->
          _menhir_run_086 _menhir_stack _menhir_lexbuf _menhir_lexer MenhirState085
      | EQ ->
          let _v_0 = _menhir_action_40 () in
          _menhir_run_088 _menhir_stack _menhir_lexbuf _menhir_lexer _v_0 MenhirState085 _tok
      | _ ->
          _menhir_fail ()
  
  and _menhir_run_088 : type  ttv_stack. (((((ttv_stack, _menhir_box_program) _menhir_cell1_JOIN, _menhir_box_program) _menhir_cell1_term_variable, _menhir_box_program) _menhir_cell1_list_formal_type_arguments_, _menhir_box_program) _menhir_cell1_list_term_arguments_ as 'stack) -> _ -> _ -> _ -> ('stack, _menhir_box_program) _menhir_state -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      let _menhir_stack = MenhirCell1_option_preceded_COLON_typ__ (_menhir_stack, _menhir_s, _v) in
      match (_tok : MenhirBasics.token) with
      | EQ ->
          let _menhir_s = MenhirState089 in
          let _tok = _menhir_lexer _menhir_lexbuf in
          (match (_tok : MenhirBasics.token) with
          | TAG _v ->
              _menhir_run_010 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s
          | MATCH ->
              _menhir_run_056 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
          | LPAR ->
              _menhir_run_057 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
          | LET ->
              _menhir_run_058 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
          | JUMP ->
              _menhir_run_066 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
          | JOIN ->
              _menhir_run_073 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
          | IDENTIFIER _v ->
              _menhir_run_059 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s
          | FUN ->
              _menhir_run_090 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
          | _ ->
              _eRR ())
      | _ ->
          _eRR ()
  
  and _menhir_run_067 : type  ttv_stack. ((ttv_stack, _menhir_box_program) _menhir_cell1_JUMP as 'stack) -> _ -> _ -> _ -> _ -> _ -> ('stack, _menhir_box_program) _menhir_state -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _startpos _v _menhir_s _tok ->
      let _menhir_stack = MenhirCell1_term_variable (_menhir_stack, _menhir_s, _v, _startpos, _endpos) in
      match (_tok : MenhirBasics.token) with
      | LBRACKET ->
          _menhir_run_068 _menhir_stack _menhir_lexbuf _menhir_lexer MenhirState067
      | LBRACE ->
          let _v_0 = _menhir_action_10 () in
          _menhir_run_071 _menhir_stack _menhir_lexbuf _menhir_lexer _v_0 MenhirState067
      | _ ->
          _eRR ()
  
  and _menhir_run_071 : type  ttv_stack. (((ttv_stack, _menhir_box_program) _menhir_cell1_JUMP, _menhir_box_program) _menhir_cell1_term_variable as 'stack) -> _ -> _ -> _ -> ('stack, _menhir_box_program) _menhir_state -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s ->
      let _menhir_stack = MenhirCell1_list_actual_type_arguments_ (_menhir_stack, _menhir_s, _v) in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | TAG _v_0 ->
          _menhir_run_010 _menhir_stack _menhir_lexbuf _menhir_lexer _v_0 MenhirState072
      | MATCH ->
          _menhir_run_056 _menhir_stack _menhir_lexbuf _menhir_lexer MenhirState072
      | LPAR ->
          _menhir_run_057 _menhir_stack _menhir_lexbuf _menhir_lexer MenhirState072
      | LET ->
          _menhir_run_058 _menhir_stack _menhir_lexbuf _menhir_lexer MenhirState072
      | JUMP ->
          _menhir_run_066 _menhir_stack _menhir_lexbuf _menhir_lexer MenhirState072
      | JOIN ->
          _menhir_run_073 _menhir_stack _menhir_lexbuf _menhir_lexer MenhirState072
      | IDENTIFIER _v_1 ->
          _menhir_run_059 _menhir_stack _menhir_lexbuf _menhir_lexer _v_1 MenhirState072
      | FUN ->
          _menhir_run_090 _menhir_stack _menhir_lexbuf _menhir_lexer MenhirState072
      | RBRACE ->
          let _v_2 = _menhir_action_46 () in
          _menhir_run_124 _menhir_stack _menhir_lexbuf _menhir_lexer _v_2 MenhirState072
      | _ ->
          _eRR ()
  
  and _menhir_run_060 : type  ttv_stack. ((ttv_stack, _menhir_box_program) _menhir_cell1_LET as 'stack) -> _ -> _ -> _ -> _ -> _ -> ('stack, _menhir_box_program) _menhir_state -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _startpos _v _menhir_s _tok ->
      let _menhir_stack = MenhirCell1_term_variable (_menhir_stack, _menhir_s, _v, _startpos, _endpos) in
      match (_tok : MenhirBasics.token) with
      | LBRACKET ->
          _menhir_run_061 _menhir_stack _menhir_lexbuf _menhir_lexer MenhirState060
      | COLON | EQ | LPAR ->
          let _v_0 = _menhir_action_12 () in
          _menhir_run_092 _menhir_stack _menhir_lexbuf _menhir_lexer _v_0 MenhirState060 _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_005 : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_program) _menhir_state -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      let _menhir_stack = MenhirCell1_type_variable (_menhir_stack, _menhir_s, _v) in
      match (_tok : MenhirBasics.token) with
      | IDENTIFIER _v_0 ->
          _menhir_run_004 _menhir_stack _menhir_lexbuf _menhir_lexer _v_0 MenhirState005
      | DATA | DOT | PROGRAM | TYPE ->
          let _v_1 = _menhir_action_20 () in
          _menhir_run_006 _menhir_stack _menhir_lexbuf _menhir_lexer _v_1 _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_006 : type  ttv_stack. (ttv_stack, _menhir_box_program) _menhir_cell1_type_variable -> _ -> _ -> _ -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let MenhirCell1_type_variable (_menhir_stack, _menhir_s, x) = _menhir_stack in
      let xs = _v in
      let _v = _menhir_action_21 x xs in
      _menhir_goto_list_type_variable_ _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
  
  and _menhir_goto_list_type_variable_ : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_program) _menhir_state -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      match _menhir_s with
      | MenhirState026 ->
          _menhir_run_027 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState013 ->
          _menhir_run_014 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState003 ->
          _menhir_run_007 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState005 ->
          _menhir_run_006 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | _ ->
          _menhir_fail ()
  
  and _menhir_run_014 : type  ttv_stack. ((ttv_stack, _menhir_box_program) _menhir_cell1_DATA, _menhir_box_program) _menhir_cell1_data_constructor -> _ -> _ -> _ -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      match (_tok : MenhirBasics.token) with
      | DOT ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let tvars = _v in
          let _v = _menhir_action_44 tvars in
          let x = _v in
          let _v = _menhir_action_26 x in
          _menhir_goto_loption_quantifiers_ _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | _ ->
          _eRR ()
  
  and _menhir_goto_loption_quantifiers_ : type  ttv_stack. ((ttv_stack, _menhir_box_program) _menhir_cell1_DATA, _menhir_box_program) _menhir_cell1_data_constructor -> _ -> _ -> _ -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _menhir_stack = MenhirCell0_loption_quantifiers_ (_menhir_stack, _v) in
      match (_tok : MenhirBasics.token) with
      | LBRACE ->
          let _menhir_s = MenhirState019 in
          let _tok = _menhir_lexer _menhir_lexbuf in
          (match (_tok : MenhirBasics.token) with
          | LPAR ->
              _menhir_run_020 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
          | IDENTIFIER _v ->
              _menhir_run_021 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s
          | FORALL ->
              _menhir_run_026 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
          | RBRACE ->
              let _v = _menhir_action_52 () in
              _menhir_goto_semi_typ_ _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s
          | _ ->
              _eRR ())
      | _ ->
          _eRR ()
  
  and _menhir_goto_semi_typ_ : type  ttv_stack. (((ttv_stack, _menhir_box_program) _menhir_cell1_DATA, _menhir_box_program) _menhir_cell1_data_constructor _menhir_cell0_loption_quantifiers_ as 'stack) -> _ -> _ -> _ -> ('stack, _menhir_box_program) _menhir_state -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s ->
      let _menhir_stack = MenhirCell1_semi_typ_ (_menhir_stack, _menhir_s, _v) in
      let _endpos = _menhir_lexbuf.Lexing.lex_curr_p in
      let _menhir_stack = MenhirCell0_RBRACE (_menhir_stack, _endpos) in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | ARROW ->
          let _menhir_s = MenhirState043 in
          let _tok = _menhir_lexer _menhir_lexbuf in
          (match (_tok : MenhirBasics.token) with
          | IDENTIFIER _v ->
              _menhir_run_002 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s
          | _ ->
              _eRR ())
      | _ ->
          _eRR ()
  
  and _menhir_run_007 : type  ttv_stack. ((ttv_stack, _menhir_box_program) _menhir_cell1_TYPE, _menhir_box_program) _menhir_cell1_type_constructor -> _ -> _ -> _ -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let MenhirCell1_type_constructor (_menhir_stack, _, tc) = _menhir_stack in
      let MenhirCell1_TYPE (_menhir_stack, _menhir_s) = _menhir_stack in
      let params = _v in
      let _v = _menhir_action_88 params tc in
      let d = _v in
      let _v = _menhir_action_64 d in
      _menhir_goto_signature_item _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
  
  and _menhir_run_103 : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> _ -> (ttv_stack, _menhir_box_program) _menhir_state -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _startpos _v _menhir_s _tok ->
      let _menhir_stack = MenhirCell1_data_constructor (_menhir_stack, _menhir_s, _v, _startpos) in
      match (_tok : MenhirBasics.token) with
      | LBRACKET ->
          _menhir_run_068 _menhir_stack _menhir_lexbuf _menhir_lexer MenhirState103
      | LBRACE ->
          let _v_0 = _menhir_action_10 () in
          _menhir_run_104 _menhir_stack _menhir_lexbuf _menhir_lexer _v_0 MenhirState103
      | _ ->
          _eRR ()
  
  and _menhir_run_104 : type  ttv_stack. ((ttv_stack, _menhir_box_program) _menhir_cell1_data_constructor as 'stack) -> _ -> _ -> _ -> ('stack, _menhir_box_program) _menhir_state -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s ->
      let _menhir_stack = MenhirCell1_list_actual_type_arguments_ (_menhir_stack, _menhir_s, _v) in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | TAG _v_0 ->
          _menhir_run_010 _menhir_stack _menhir_lexbuf _menhir_lexer _v_0 MenhirState105
      | MATCH ->
          _menhir_run_056 _menhir_stack _menhir_lexbuf _menhir_lexer MenhirState105
      | LPAR ->
          _menhir_run_057 _menhir_stack _menhir_lexbuf _menhir_lexer MenhirState105
      | LET ->
          _menhir_run_058 _menhir_stack _menhir_lexbuf _menhir_lexer MenhirState105
      | JUMP ->
          _menhir_run_066 _menhir_stack _menhir_lexbuf _menhir_lexer MenhirState105
      | JOIN ->
          _menhir_run_073 _menhir_stack _menhir_lexbuf _menhir_lexer MenhirState105
      | IDENTIFIER _v_1 ->
          _menhir_run_059 _menhir_stack _menhir_lexbuf _menhir_lexer _v_1 MenhirState105
      | FUN ->
          _menhir_run_090 _menhir_stack _menhir_lexbuf _menhir_lexer MenhirState105
      | RBRACE ->
          let _v_2 = _menhir_action_46 () in
          _menhir_run_107 _menhir_stack _menhir_lexbuf _menhir_lexer _v_2
      | _ ->
          _eRR ()
  
  and _menhir_run_011 : type  ttv_stack. ((ttv_stack, _menhir_box_program) _menhir_cell1_DATA as 'stack) -> _ -> _ -> _ -> _ -> ('stack, _menhir_box_program) _menhir_state -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _startpos _v _menhir_s _tok ->
      let _menhir_stack = MenhirCell1_data_constructor (_menhir_stack, _menhir_s, _v, _startpos) in
      match (_tok : MenhirBasics.token) with
      | COLON ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          (match (_tok : MenhirBasics.token) with
          | FORALL ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              (match (_tok : MenhirBasics.token) with
              | IDENTIFIER _v_0 ->
                  _menhir_run_004 _menhir_stack _menhir_lexbuf _menhir_lexer _v_0 MenhirState013
              | DOT ->
                  let _v_1 = _menhir_action_20 () in
                  _menhir_run_014 _menhir_stack _menhir_lexbuf _menhir_lexer _v_1 _tok
              | _ ->
                  _eRR ())
          | LBRACE ->
              let _v = _menhir_action_25 () in
              _menhir_goto_loption_quantifiers_ _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
          | _ ->
              _eRR ())
      | _ ->
          _eRR ()
  
  and _menhir_run_051 : type  ttv_stack. (ttv_stack, _menhir_box_program) _menhir_cell1_signature_item -> _ -> _ -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v ->
      let MenhirCell1_signature_item (_menhir_stack, _menhir_s, x) = _menhir_stack in
      let xs = _v in
      let _v = _menhir_action_15 x xs in
      _menhir_goto_list_signature_item_ _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s
  
  and _menhir_goto_list_signature_item_ : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_program) _menhir_state -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s ->
      match _menhir_s with
      | MenhirState000 ->
          _menhir_run_054 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s
      | MenhirState050 ->
          _menhir_run_051 _menhir_stack _menhir_lexbuf _menhir_lexer _v
      | _ ->
          _menhir_fail ()
  
  and _menhir_run_054 : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_program) _menhir_state -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s ->
      let _menhir_stack = MenhirCell1_list_signature_item_ (_menhir_stack, _menhir_s, _v) in
      let _menhir_s = MenhirState055 in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | TAG _v ->
          _menhir_run_010 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s
      | MATCH ->
          _menhir_run_056 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
      | LPAR ->
          _menhir_run_057 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
      | LET ->
          _menhir_run_058 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
      | JUMP ->
          _menhir_run_066 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
      | JOIN ->
          _menhir_run_073 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
      | IDENTIFIER _v ->
          _menhir_run_059 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s
      | FUN ->
          _menhir_run_090 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
      | _ ->
          _eRR ()
  
  and _menhir_run_031 : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> _ -> (ttv_stack, _menhir_box_program) _menhir_state -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _v _menhir_s _tok ->
      let (_endpos_ty_, ty) = (_endpos, _v) in
      let _v = _menhir_action_86 ty in
      _menhir_goto_typ1 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos_ty_ _v _menhir_s _tok
  
  and _menhir_goto_typ1 : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> _ -> (ttv_stack, _menhir_box_program) _menhir_state -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _v _menhir_s _tok ->
      match (_tok : MenhirBasics.token) with
      | ARROW ->
          let _menhir_stack = MenhirCell1_typ1 (_menhir_stack, _menhir_s, _v, _endpos) in
          let _menhir_s = MenhirState030 in
          let _tok = _menhir_lexer _menhir_lexbuf in
          (match (_tok : MenhirBasics.token) with
          | LPAR ->
              _menhir_run_020 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
          | IDENTIFIER _v ->
              _menhir_run_021 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s
          | FORALL ->
              _menhir_run_026 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
          | _ ->
              _eRR ())
      | BAR | COLON | END | EOF | EQ | IDENTIFIER _ | IN | JUMP | LBRACKET | LPAR | MATCH | RBRACE | RBRACKET | RETURN | RPAR | SEMI | TAG _ | WITH ->
          let (_endpos_ty_, ty) = (_endpos, _v) in
          let _v = _menhir_action_80 ty in
          _menhir_goto_typ _menhir_stack _menhir_lexbuf _menhir_lexer _endpos_ty_ _v _menhir_s _tok
      | _ ->
          _eRR ()
  
  and _menhir_goto_typ : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> _ -> (ttv_stack, _menhir_box_program) _menhir_state -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _v _menhir_s _tok ->
      match _menhir_s with
      | MenhirState136 ->
          _menhir_run_137 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _v _menhir_s _tok
      | MenhirState132 ->
          _menhir_run_133 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState126 ->
          _menhir_run_127 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _v _tok
      | MenhirState086 ->
          _menhir_run_087 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState080 ->
          _menhir_run_081 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState068 ->
          _menhir_run_069 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState037 ->
          _menhir_run_036 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _v _menhir_s _tok
      | MenhirState019 ->
          _menhir_run_036 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _v _menhir_s _tok
      | MenhirState020 ->
          _menhir_run_034 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState028 ->
          _menhir_run_033 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _v _tok
      | MenhirState030 ->
          _menhir_run_032 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _v _tok
      | _ ->
          _menhir_fail ()
  
  and _menhir_run_137 : type  ttv_stack. (((ttv_stack, _menhir_box_program) _menhir_cell1_MATCH, _menhir_box_program) _menhir_cell1_loc_term_ as 'stack) -> _ -> _ -> _ -> _ -> ('stack, _menhir_box_program) _menhir_state -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _v _menhir_s _tok ->
      let _menhir_stack = MenhirCell1_typ (_menhir_stack, _menhir_s, _v, _endpos) in
      match (_tok : MenhirBasics.token) with
      | WITH ->
          let _menhir_s = MenhirState138 in
          let _tok = _menhir_lexer _menhir_lexbuf in
          (match (_tok : MenhirBasics.token) with
          | TAG _v ->
              _menhir_run_010 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s
          | BAR ->
              _menhir_run_139 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
          | END ->
              let _v = _menhir_action_02 () in
              _menhir_goto_bar_clause_ _menhir_stack _menhir_lexbuf _menhir_lexer _v
          | _ ->
              _eRR ())
      | _ ->
          _eRR ()
  
  and _menhir_run_133 : type  ttv_stack. ((ttv_stack, _menhir_box_program) _menhir_cell1_LPAR, _menhir_box_program) _menhir_cell1_loc_term_ -> _ -> _ -> _ -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      match (_tok : MenhirBasics.token) with
      | RPAR ->
          let _endpos_0 = _menhir_lexbuf.Lexing.lex_curr_p in
          let _tok = _menhir_lexer _menhir_lexbuf in
          let MenhirCell1_loc_term_ (_menhir_stack, _, t, _) = _menhir_stack in
          let MenhirCell1_LPAR (_menhir_stack, _menhir_s, _startpos__1_) = _menhir_stack in
          let (ty, _endpos__5_) = (_v, _endpos_0) in
          let _v = _menhir_action_73 t ty in
          _menhir_goto_term0 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos__5_ _startpos__1_ _v _menhir_s _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_127 : type  ttv_stack. ((((ttv_stack, _menhir_box_program) _menhir_cell1_JUMP, _menhir_box_program) _menhir_cell1_term_variable, _menhir_box_program) _menhir_cell1_list_actual_type_arguments_, _menhir_box_program) _menhir_cell1_semi_loc_term__ _menhir_cell0_RBRACE -> _ -> _ -> _ -> _ -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _v _tok ->
      let MenhirCell0_RBRACE (_menhir_stack, _) = _menhir_stack in
      let MenhirCell1_semi_loc_term__ (_menhir_stack, _, args) = _menhir_stack in
      let MenhirCell1_list_actual_type_arguments_ (_menhir_stack, _, xs) = _menhir_stack in
      let MenhirCell1_term_variable (_menhir_stack, _, j, _, _) = _menhir_stack in
      let MenhirCell1_JUMP (_menhir_stack, _menhir_s, _startpos__1_) = _menhir_stack in
      let (_endpos_ret_ty_, ret_ty) = (_endpos, _v) in
      let _v = _menhir_action_71 args j ret_ty xs in
      _menhir_goto_term0 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos_ret_ty_ _startpos__1_ _v _menhir_s _tok
  
  and _menhir_run_087 : type  ttv_stack. (((ttv_stack, _menhir_box_program) _menhir_cell1_list_formal_type_arguments_, _menhir_box_program) _menhir_cell1_list_term_arguments_, _menhir_box_program) _menhir_cell1_COLON -> _ -> _ -> _ -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let MenhirCell1_COLON (_menhir_stack, _menhir_s) = _menhir_stack in
      let x = _v in
      let _v = _menhir_action_41 x in
      _menhir_goto_option_preceded_COLON_typ__ _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
  
  and _menhir_goto_option_preceded_COLON_typ__ : type  ttv_stack. (((ttv_stack, _menhir_box_program) _menhir_cell1_list_formal_type_arguments_, _menhir_box_program) _menhir_cell1_list_term_arguments_ as 'stack) -> _ -> _ -> _ -> ('stack, _menhir_box_program) _menhir_state -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      match _menhir_s with
      | MenhirState093 ->
          _menhir_run_094 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState085 ->
          _menhir_run_088 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | _ ->
          _menhir_fail ()
  
  and _menhir_run_081 : type  ttv_stack. ((ttv_stack, _menhir_box_program) _menhir_cell1_LPAR, _menhir_box_program) _menhir_cell1_nonempty_list_term_variable_ -> _ -> _ -> _ -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      match (_tok : MenhirBasics.token) with
      | RPAR ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let MenhirCell1_nonempty_list_term_variable_ (_menhir_stack, _, xs) = _menhir_stack in
          let MenhirCell1_LPAR (_menhir_stack, _menhir_s, _) = _menhir_stack in
          let domain = _v in
          let _v = _menhir_action_78 domain xs in
          let _menhir_stack = MenhirCell1_term_arguments (_menhir_stack, _menhir_s, _v) in
          (match (_tok : MenhirBasics.token) with
          | LPAR ->
              _menhir_run_076 _menhir_stack _menhir_lexbuf _menhir_lexer MenhirState083
          | COLON | EQ ->
              let _v_0 = _menhir_action_16 () in
              _menhir_run_084 _menhir_stack _menhir_lexbuf _menhir_lexer _v_0 _tok
          | _ ->
              _eRR ())
      | _ ->
          _eRR ()
  
  and _menhir_run_084 : type  ttv_stack. (ttv_stack, _menhir_box_program) _menhir_cell1_term_arguments -> _ -> _ -> _ -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let MenhirCell1_term_arguments (_menhir_stack, _menhir_s, x) = _menhir_stack in
      let xs = _v in
      let _v = _menhir_action_17 x xs in
      _menhir_goto_list_term_arguments_ _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
  
  and _menhir_goto_list_term_arguments_ : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_program) _menhir_state -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      match _menhir_s with
      | MenhirState092 ->
          _menhir_run_093 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState075 ->
          _menhir_run_085 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState083 ->
          _menhir_run_084 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | _ ->
          _menhir_fail ()
  
  and _menhir_run_069 : type  ttv_stack. (ttv_stack, _menhir_box_program) _menhir_cell1_LBRACKET -> _ -> _ -> _ -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      match (_tok : MenhirBasics.token) with
      | RBRACKET ->
          let _endpos_0 = _menhir_lexbuf.Lexing.lex_curr_p in
          let _tok = _menhir_lexer _menhir_lexbuf in
          let MenhirCell1_LBRACKET (_menhir_stack, _menhir_s) = _menhir_stack in
          let (_endpos__3_, tys) = (_endpos_0, _v) in
          let _v = _menhir_action_01 tys in
          _menhir_goto_actual_type_arguments _menhir_stack _menhir_lexbuf _menhir_lexer _endpos__3_ _v _menhir_s _tok
      | _ ->
          _eRR ()
  
  and _menhir_goto_actual_type_arguments : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> _ -> (ttv_stack, _menhir_box_program) _menhir_state -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _v _menhir_s _tok ->
      match _menhir_s with
      | MenhirState100 ->
          _menhir_run_116 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _v _tok
      | MenhirState067 ->
          _menhir_run_114 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _v _menhir_s _tok
      | MenhirState114 ->
          _menhir_run_114 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _v _menhir_s _tok
      | MenhirState103 ->
          _menhir_run_114 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _v _menhir_s _tok
      | _ ->
          _menhir_fail ()
  
  and _menhir_run_116 : type  ttv_stack. (ttv_stack, _menhir_box_program) _menhir_cell1_loc_term1_ -> _ -> _ -> _ -> _ -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _v _tok ->
      let MenhirCell1_loc_term1_ (_menhir_stack, _menhir_s, t, _startpos_t_) = _menhir_stack in
      let (_endpos_tys_, tys) = (_endpos, _v) in
      let _v = _menhir_action_77 t tys in
      _menhir_goto_term1 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos_tys_ _startpos_t_ _v _menhir_s _tok
  
  and _menhir_run_114 : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> _ -> (ttv_stack, _menhir_box_program) _menhir_state -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _v _menhir_s _tok ->
      let _menhir_stack = MenhirCell1_actual_type_arguments (_menhir_stack, _menhir_s, _v, _endpos) in
      match (_tok : MenhirBasics.token) with
      | LBRACKET ->
          _menhir_run_068 _menhir_stack _menhir_lexbuf _menhir_lexer MenhirState114
      | LBRACE ->
          let _v_0 = _menhir_action_10 () in
          _menhir_run_115 _menhir_stack _menhir_lexbuf _menhir_lexer _v_0
      | _ ->
          _eRR ()
  
  and _menhir_run_115 : type  ttv_stack. (ttv_stack, _menhir_box_program) _menhir_cell1_actual_type_arguments -> _ -> _ -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v ->
      let MenhirCell1_actual_type_arguments (_menhir_stack, _menhir_s, x, _) = _menhir_stack in
      let xs = _v in
      let _v = _menhir_action_11 x xs in
      _menhir_goto_list_actual_type_arguments_ _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s
  
  and _menhir_goto_list_actual_type_arguments_ : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_program) _menhir_state -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s ->
      match _menhir_s with
      | MenhirState114 ->
          _menhir_run_115 _menhir_stack _menhir_lexbuf _menhir_lexer _v
      | MenhirState103 ->
          _menhir_run_104 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s
      | MenhirState067 ->
          _menhir_run_071 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s
      | _ ->
          _menhir_fail ()
  
  and _menhir_run_036 : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> _ -> (ttv_stack, _menhir_box_program) _menhir_state -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _v _menhir_s _tok ->
      match (_tok : MenhirBasics.token) with
      | SEMI ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          (match (_tok : MenhirBasics.token) with
          | LPAR ->
              let _menhir_stack = MenhirCell1_typ (_menhir_stack, _menhir_s, _v, _endpos) in
              _menhir_run_020 _menhir_stack _menhir_lexbuf _menhir_lexer MenhirState037
          | IDENTIFIER _v_0 ->
              let _menhir_stack = MenhirCell1_typ (_menhir_stack, _menhir_s, _v, _endpos) in
              _menhir_run_021 _menhir_stack _menhir_lexbuf _menhir_lexer _v_0 MenhirState037
          | FORALL ->
              let _menhir_stack = MenhirCell1_typ (_menhir_stack, _menhir_s, _v, _endpos) in
              _menhir_run_026 _menhir_stack _menhir_lexbuf _menhir_lexer MenhirState037
          | RBRACE ->
              let x = _v in
              let _v = _menhir_action_36 x in
              _menhir_goto_nonempty_list_terminated_typ_SEMI__ _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s
          | _ ->
              _eRR ())
      | RBRACE ->
          let x = _v in
          let _v = _menhir_action_61 x in
          _menhir_goto_separated_nonempty_list_SEMI_typ_ _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s
      | _ ->
          _eRR ()
  
  and _menhir_goto_nonempty_list_terminated_typ_SEMI__ : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_program) _menhir_state -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s ->
      match _menhir_s with
      | MenhirState019 ->
          _menhir_run_048 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s
      | MenhirState037 ->
          _menhir_run_039 _menhir_stack _menhir_lexbuf _menhir_lexer _v
      | _ ->
          _menhir_fail ()
  
  and _menhir_run_048 : type  ttv_stack. (((ttv_stack, _menhir_box_program) _menhir_cell1_DATA, _menhir_box_program) _menhir_cell1_data_constructor _menhir_cell0_loption_quantifiers_ as 'stack) -> _ -> _ -> _ -> ('stack, _menhir_box_program) _menhir_state -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s ->
      let xs = _v in
      let _v = _menhir_action_53 xs in
      _menhir_goto_semi_typ_ _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s
  
  and _menhir_run_039 : type  ttv_stack. (ttv_stack, _menhir_box_program) _menhir_cell1_typ -> _ -> _ -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v ->
      let MenhirCell1_typ (_menhir_stack, _menhir_s, x, _) = _menhir_stack in
      let xs = _v in
      let _v = _menhir_action_37 x xs in
      _menhir_goto_nonempty_list_terminated_typ_SEMI__ _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s
  
  and _menhir_goto_separated_nonempty_list_SEMI_typ_ : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_program) _menhir_state -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s ->
      match _menhir_s with
      | MenhirState019 ->
          _menhir_run_040 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s
      | MenhirState037 ->
          _menhir_run_038 _menhir_stack _menhir_lexbuf _menhir_lexer _v
      | _ ->
          _menhir_fail ()
  
  and _menhir_run_040 : type  ttv_stack. (((ttv_stack, _menhir_box_program) _menhir_cell1_DATA, _menhir_box_program) _menhir_cell1_data_constructor _menhir_cell0_loption_quantifiers_ as 'stack) -> _ -> _ -> _ -> ('stack, _menhir_box_program) _menhir_state -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s ->
      let xs = _v in
      let _v = _menhir_action_54 xs in
      _menhir_goto_semi_typ_ _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s
  
  and _menhir_run_038 : type  ttv_stack. (ttv_stack, _menhir_box_program) _menhir_cell1_typ -> _ -> _ -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v ->
      let MenhirCell1_typ (_menhir_stack, _menhir_s, x, _) = _menhir_stack in
      let xs = _v in
      let _v = _menhir_action_62 x xs in
      _menhir_goto_separated_nonempty_list_SEMI_typ_ _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s
  
  and _menhir_run_034 : type  ttv_stack. (ttv_stack, _menhir_box_program) _menhir_cell1_LPAR -> _ -> _ -> _ -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      match (_tok : MenhirBasics.token) with
      | RPAR ->
          let _endpos_0 = _menhir_lexbuf.Lexing.lex_curr_p in
          let _tok = _menhir_lexer _menhir_lexbuf in
          let MenhirCell1_LPAR (_menhir_stack, _menhir_s, _) = _menhir_stack in
          let (ty, _endpos__3_) = (_v, _endpos_0) in
          let _v = _menhir_action_84 ty in
          _menhir_goto_typ0 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos__3_ _v _menhir_s _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_033 : type  ttv_stack. ((ttv_stack, _menhir_box_program) _menhir_cell1_FORALL, _menhir_box_program) _menhir_cell1_list_type_variable_ -> _ -> _ -> _ -> _ -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _v _tok ->
      let MenhirCell1_list_type_variable_ (_menhir_stack, _, tvars) = _menhir_stack in
      let MenhirCell1_FORALL (_menhir_stack, _menhir_s) = _menhir_stack in
      let (_endpos_ty_, ty) = (_endpos, _v) in
      let _v = _menhir_action_82 tvars ty in
      _menhir_goto_typ _menhir_stack _menhir_lexbuf _menhir_lexer _endpos_ty_ _v _menhir_s _tok
  
  and _menhir_run_032 : type  ttv_stack. (ttv_stack, _menhir_box_program) _menhir_cell1_typ1 -> _ -> _ -> _ -> _ -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _v _tok ->
      let MenhirCell1_typ1 (_menhir_stack, _menhir_s, ty1, _) = _menhir_stack in
      let (_endpos_ty2_, ty2) = (_endpos, _v) in
      let _v = _menhir_action_81 ty1 ty2 in
      _menhir_goto_typ _menhir_stack _menhir_lexbuf _menhir_lexer _endpos_ty2_ _v _menhir_s _tok
  
  and _menhir_run_023 : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> _ -> (ttv_stack, _menhir_box_program) _menhir_state -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _v _menhir_s _tok ->
      match (_tok : MenhirBasics.token) with
      | LPAR ->
          let _menhir_stack = MenhirCell1_typ0 (_menhir_stack, _menhir_s, _v, _endpos) in
          _menhir_run_020 _menhir_stack _menhir_lexbuf _menhir_lexer MenhirState023
      | IDENTIFIER _v_0 ->
          let _menhir_stack = MenhirCell1_typ0 (_menhir_stack, _menhir_s, _v, _endpos) in
          _menhir_run_022 _menhir_stack _menhir_lexbuf _menhir_lexer _v_0 MenhirState023
      | ARROW | BAR | COLON | END | EOF | EQ | IN | JUMP | LBRACKET | MATCH | RBRACE | RBRACKET | RETURN | RPAR | SEMI | TAG _ | WITH ->
          let (_endpos_x_, x) = (_endpos, _v) in
          let _v = _menhir_action_38 x in
          _menhir_goto_nonempty_list_typ0_ _menhir_stack _menhir_lexbuf _menhir_lexer _endpos_x_ _v _menhir_s _tok
      | _ ->
          _eRR ()
  
  and _menhir_goto_nonempty_list_typ0_ : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> _ -> (ttv_stack, _menhir_box_program) _menhir_state -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _v _menhir_s _tok ->
      match _menhir_s with
      | MenhirState021 ->
          _menhir_run_025 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _v _tok
      | MenhirState023 ->
          _menhir_run_024 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _v _tok
      | _ ->
          _menhir_fail ()
  
  and _menhir_run_025 : type  ttv_stack. (ttv_stack, _menhir_box_program) _menhir_cell1_IDENTIFIER -> _ -> _ -> _ -> _ -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _v _tok ->
      let MenhirCell1_IDENTIFIER (_menhir_stack, _menhir_s, id, _, _) = _menhir_stack in
      let (_endpos_params_, params) = (_endpos, _v) in
      let _v = _menhir_action_85 id params in
      _menhir_goto_typ1 _menhir_stack _menhir_lexbuf _menhir_lexer _endpos_params_ _v _menhir_s _tok
  
  and _menhir_run_024 : type  ttv_stack. (ttv_stack, _menhir_box_program) _menhir_cell1_typ0 -> _ -> _ -> _ -> _ -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _endpos _v _tok ->
      let MenhirCell1_typ0 (_menhir_stack, _menhir_s, x, _) = _menhir_stack in
      let (_endpos_xs_, xs) = (_endpos, _v) in
      let _v = _menhir_action_39 x xs in
      _menhir_goto_nonempty_list_typ0_ _menhir_stack _menhir_lexbuf _menhir_lexer _endpos_xs_ _v _menhir_s _tok
  
  and _menhir_run_003 : type  ttv_stack. ((ttv_stack, _menhir_box_program) _menhir_cell1_TYPE as 'stack) -> _ -> _ -> _ -> ('stack, _menhir_box_program) _menhir_state -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      let _menhir_stack = MenhirCell1_type_constructor (_menhir_stack, _menhir_s, _v) in
      match (_tok : MenhirBasics.token) with
      | IDENTIFIER _v_0 ->
          _menhir_run_004 _menhir_stack _menhir_lexbuf _menhir_lexer _v_0 MenhirState003
      | DATA | PROGRAM | TYPE ->
          let _v_1 = _menhir_action_20 () in
          _menhir_run_007 _menhir_stack _menhir_lexbuf _menhir_lexer _v_1 _tok
      | _ ->
          _eRR ()
  
  let _menhir_run_000 : type  ttv_stack. ttv_stack -> _ -> _ -> _menhir_box_program =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer ->
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | TYPE ->
          _menhir_run_001 _menhir_stack _menhir_lexbuf _menhir_lexer MenhirState000
      | DATA ->
          _menhir_run_008 _menhir_stack _menhir_lexbuf _menhir_lexer MenhirState000
      | PROGRAM ->
          let _v = _menhir_action_14 () in
          _menhir_run_054 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState000
      | _ ->
          _eRR ()
  
end

let program =
  fun _menhir_lexer _menhir_lexbuf ->
    let _menhir_stack = () in
    let MenhirBox_program v = _menhir_run_000 _menhir_stack _menhir_lexbuf _menhir_lexer in
    v
