tsubst.pp.mli: Atom Types
