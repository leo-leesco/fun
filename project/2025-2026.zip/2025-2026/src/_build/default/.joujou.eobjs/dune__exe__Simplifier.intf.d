simplifier.pp.mli: Terms Types
