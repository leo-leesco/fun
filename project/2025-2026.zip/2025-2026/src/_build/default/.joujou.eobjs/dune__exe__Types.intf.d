types.pp.mli: Atom Format Identifier
