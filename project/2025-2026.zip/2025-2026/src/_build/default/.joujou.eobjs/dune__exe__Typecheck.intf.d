typecheck.pp.mli: Export Terms Types
