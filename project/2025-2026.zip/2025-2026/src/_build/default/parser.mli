
(* The type of tokens. *)

type token = 
  | WITH
  | TYPE
  | TAG of (string * Lexing.position * Lexing.position)
  | SEMI
  | RPAR
  | RETURN
  | RBRACKET
  | RBRACE
  | PROGRAM
  | MATCH
  | LPAR
  | LET
  | LBRACKET
  | LBRACE
  | JUMP
  | JOIN
  | IN
  | IDENTIFIER of (string * Lexing.position * Lexing.position)
  | FUN
  | FORALL
  | EQ
  | EOF
  | END
  | DOT
  | DATA
  | CONSTRUCTOR
  | COLON
  | BAR
  | ARROW

(* This exception is raised by the monolithic API functions. *)

exception Error

(* The monolithic API. *)

val program: (Lexing.lexbuf -> token) -> Lexing.lexbuf -> (Syntax.program)
