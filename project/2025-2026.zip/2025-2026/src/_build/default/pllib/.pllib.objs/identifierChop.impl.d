pllib/identifierChop.ml: Array Lexing
