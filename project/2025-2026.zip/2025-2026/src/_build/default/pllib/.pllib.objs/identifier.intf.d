pllib/identifier.mli: Format Lexing Map
