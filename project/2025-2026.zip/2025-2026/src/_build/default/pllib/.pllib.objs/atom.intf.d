pllib/atom.mli: Format Identifier Map Set
