pllib/lexerUtil.ml: Hashtbl Lexing List
