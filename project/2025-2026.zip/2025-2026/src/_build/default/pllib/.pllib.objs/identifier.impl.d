pllib/identifier.ml: Format IdentifierChop Lexing Map Stdlib String
