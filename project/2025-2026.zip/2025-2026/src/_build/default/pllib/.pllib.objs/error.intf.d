pllib/error.mli: Atom Format Lexing
