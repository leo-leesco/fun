pllib/export.mli: Atom Identifier
