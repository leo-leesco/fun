pllib/lexerUtil.mli: Lexing
