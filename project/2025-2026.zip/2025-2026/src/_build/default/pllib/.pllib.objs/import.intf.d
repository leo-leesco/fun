pllib/import.mli: Atom Identifier Lexing
