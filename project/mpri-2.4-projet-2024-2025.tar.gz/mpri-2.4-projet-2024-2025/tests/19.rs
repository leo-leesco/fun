fn f() {}

// BAD : f is not a type name
fn g(x: f) {}