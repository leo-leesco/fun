fn f(b : bool) {
    let mut x : i32;
    if b {
        x = 12i32;
    } else {
        x = 13i32;
    }

    x = x+1i32
}
