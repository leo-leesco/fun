// BAD: unknown type A
fn f(x: A) {}