// BAD: duplicated parameter name x
fn f(x: i32, mut x: i32) {}
