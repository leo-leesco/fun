// BAD : unused lifetime name 'a
struct S<'a> {}
