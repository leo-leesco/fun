struct S {
    // BAD : duplicated field name x
    x : i32,
    x : i32
}