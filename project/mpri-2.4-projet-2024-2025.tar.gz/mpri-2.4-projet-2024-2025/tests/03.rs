fn f() -> i32 {
    return 1i32
}