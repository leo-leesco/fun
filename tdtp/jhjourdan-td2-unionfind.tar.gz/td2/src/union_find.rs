use std::{cell::RefCell, rc::Rc};

// A 'smart pointeur' to a node of union-find
#[derive(PartialEq, Eq, Debug)]
pub struct Node<T>(Rc<RefCell<Inner<T>>>);

impl<T> Clone for Node<T> {
    fn clone(&self) -> Self {
        Self(self.0.clone())
    }
}

#[derive(PartialEq, Eq, Debug)]
enum Inner<T> {
    Root { data: T },
    Link { parent: Node<T> },
}

impl<T: Eq> Node<T> {
    pub fn new(data: T) -> Self {
        Node(Rc::new(RefCell::new(Inner::Root { data })))
    }

    /// Compute and returns the canonical representative of the class of `self`
    pub fn naive_find(&self) -> Self {
        todo!()
    }

    /// Merges the equivalence classes of `self` and `rhs` so that they have the
    /// same representative
    pub fn naive_union(&self, rhs: &Self) {
        todo!()
    }

    /// Computes and returns the representative of `self`.
    /// (Optimized version with path compression)
    pub fn find(&self) -> Self {
        todo!()
    }

    /// Merges the equivalence classes of `self` and `rhs` so that they have the
    /// same representative
    /// (Optimized version with path compression)
    pub fn union(&self, rhs: &Self) {
        todo!()
    }
}

#[cfg(test)]
mod tests {
    use super::Node;

    #[test]
    fn version_naive() {
        let x = Node::new(0);
        assert_eq!(x.naive_find(), x);

        let y = Node::new(1);
        let z = Node::new(2);

        assert!(x.naive_find() != y.naive_find());

        x.naive_union(&y);

        assert_eq!(x.naive_find(), y.naive_find());

        y.naive_union(&z);

        assert_eq!(x.naive_find(), z.naive_find());
        assert_eq!(y.naive_find(), z.naive_find());
    }

    #[test]
    fn union_opti() {
        let x = Node::new(0);
        assert_eq!(x.naive_find(), x);

        let y = Node::new(1);
        let z = Node::new(2);

        assert!(x.naive_find() != y.naive_find());

        x.union(&y);

        assert_eq!(x.naive_find(), y.naive_find());

        y.union(&z);

        assert_eq!(x.naive_find(), z.naive_find());
        assert_eq!(y.naive_find(), z.naive_find());
    }

    #[test]
    fn union_and_find_opti() {
        let x = Node::new(0);
        assert_eq!(x.find(), x);

        let y = Node::new(1);
        let z = Node::new(2);

        assert!(x.find() != y.find());

        x.union(&y);

        assert_eq!(x.find(), y.find());

        y.union(&z);

        assert_eq!(x.find(), z.find());
        assert_eq!(y.find(), z.find());
    }

    // Run with `cargo test -- --ignored perf_naive`
    #[ignore]
    #[test]
    fn perf_naive() {
        let x = Node::new(0);

        for i in 0..100_000 {
            x.naive_union(&Node::new(i));
        }

        for i in 0..100_000 {
            Node::new(i).naive_union(&x);
        }

        std::mem::forget(x); // Necessary to avoid stack overflow :(
    }

    // Run with `cargo test -- --ignored perf_opti_union`
    #[ignore]
    #[test]
    fn perf_opti_union() {
        let x = Node::new(0);

        for i in 0..1_000_000 {
            x.union(&Node::new(i));
        }

        for i in 0..1_000_000 {
            Node::new(i).union(&x);
        }
    }
}
